#include <nds.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "ftp.h"
//#include "CardRead.h"
#include "cardme.h"
#include "command.h"

extern	char	GameTitle[13];
extern	char	Gamecode[5];
extern	char	RomVer;
extern	u32	Devicecapacity;
extern	u32	UsedROMsize;

extern	int	savetype;
extern	u32	savesize;

extern	char	*romhead;
extern	char	*romsc1;
extern	char	*romsc2;


u8	savebuf[512];

//extern	u32	arm9fifo;
extern "C" {
//	void FIFOSend(u32 val);
	void dsp_bar(int mod, int per);
	int	Read_Data(u8* dbuf, u32 addr);
}


int SaveBK_upd(char *name)
{
	int	ret;
	u32	add;
	int	per;
	u32	siz;

	dsp_bar(0, -1);

	ret = FTP_FileOpen(1, name);
	if(!ret) {
		dsp_bar(-1, 0);
		return false;
	}

	siz = ini.save * 1024;
	if(siz < savesize)
		siz = savesize;

	for(add = 0; add < savesize; add += 512) {
		cardmeReadEeprom(add, savebuf, 512, savetype); 
		per = (add * 100) / siz;
		dsp_bar(0, per);
		FTP_FileWrite((char *)savebuf, 512);
	}

	memset((char *)savebuf, 0xFF, 512);
	for(; add < siz; add += 512) {
		per = (add * 100) / siz;
		dsp_bar(0, per);
		FTP_FileWrite((char *)savebuf, 512);
	}
	dsp_bar(0, 100);

	FTP_FileClose();
	dsp_bar(-1, 0);

	if(FTP_FileSize(name) != (int)siz)
		return false;
	return true;
}


void SaveBK_new(char *name)
{
	char	tm[16];
	char	tmn[16];
	int	no, n;

	dsp_bar(2, -2);

	tmn[0] = 0;
	n = 0;
	for(no = 0; no < 100; no++) {
		sprintf(name, "%s_%s_%02d.sav", GameTitle, Gamecode, no);
		if(FTP_FileTM(name, tm) == false)
			break;

		if((tmn[0] == 0) || (strcmp(tm, tmn) < 0)) {
			strcpy(tmn, tm);
			n = no;
		}
	}

	if(no == 100) {
		no = n;
		sprintf(name, "%s_%s_%02d.sav", GameTitle, Gamecode, no);
	}

	dsp_bar(-1, 0);

	return;
}

/***
extern "C" {
extern void ShinoPrint_SUB( uint16* screen, int x, int y, u8 *st, u16 Fpalet, u16 Bpalet, u8 kaki );
extern	u32 inp_key();
}
extern uint16* SubScreen;
***/


int Save_Rest(char *name)
{
	int	ret;
	u32	add;
	int	per;
	int	len;

	if(savetype == 3) {
		dsp_bar(3, -1);
		for(add = 0; add < savesize; add += 0x10000) {
			per = (add * 100) / savesize;
			dsp_bar(3, per);
			cardmeSectorErase(add);
		}
		dsp_bar(-1, 0);
	}

	dsp_bar(1, -1);
	ret = FTP_FileOpen(0, name);
	if(!ret) {
		dsp_bar(-1, 0);
		return false;
	}

	for(add = 0; add < savesize; ) {
		per = (add * 100) / savesize;
		dsp_bar(1, per);
		len = savesize - add;
		if(len > 512)	len = 512;
		len = FTP_FileRead((char *)savebuf, len);
		if(len > 0) {
			cardmeWriteEeprom(add, savebuf, len, savetype);
			add += len;
		}
	}
	dsp_bar(1, 100);

	FTP_Abort();
	FTP_FileClose();
	dsp_bar(-1, 0);

	return true;
}

int Save_Init()
{

	u32	add;
	int	per;
	int	len;

	if(savetype == 3) {
		dsp_bar(3, -1);
		for(add = 0; add < savesize; add += 0x10000) {
			per = (add * 100) / savesize;
			dsp_bar(3, per);
			cardmeSectorErase(add);
		}
		dsp_bar(3, 100);
		dsp_bar(-1, 0);
		return true;
	}

	dsp_bar(3, -1);
	memset((char *)savebuf, 0xFF, 512);
	for(add = 0; add < savesize; ) {
		per = (add * 100) / savesize;
		dsp_bar(3, per);
		len = savesize - add;
		if(len > 512)	len = 512;
		cardmeWriteEeprom(add, savebuf, len, savetype);
		add += len;
	}
	dsp_bar(3, 100);
	dsp_bar(-1, 0);

	return true;
}



int RomBK_upd(char *name)
{
	int	ret;
	u32	add;
	int	per;
	u32	siz;
	char	*ptr;

	dsp_bar(4, -1);

	siz = Devicecapacity;
	if(ini.trim != 0) {
		siz = UsedROMsize;
		siz = ((siz + 511) / 512) * 512;
//		siz = ((siz + 1023) / 1024) * 1024;
	}


	ret = FTP_FileOpen(1, name);
	if(!ret) {
		dsp_bar(-1, 0);
		return false;
	}

	FTP_FileWrite((char *)romhead, 512);

	memset((char *)romsc2, 0x00, 512);
	for(add = 512; add < 0x4000; add += 512) {
		per = (int)(((u64)add * 100) / siz);
		dsp_bar(4, per);
		FTP_FileWrite((char *)romsc2, 512);
	}

	ptr = (char *)romsc1;
	for(add = 0x4000; add < 0x8000; add += 512) {
		per = (int)(((u64)add * 100) / siz);
		dsp_bar(4, per);
		FTP_FileWrite((char *)ptr, 512);
		ptr += 512;
	}

	for(add = 0x8000; add < siz; add += 512) {
		Read_Data((u8*)romsc2, add);
		per = (int)(((u64)add * 100) / siz);
		dsp_bar(4, per);
		FTP_FileWrite(romsc2, 512);
	}


	dsp_bar(4, 100);

	FTP_FileClose();
	dsp_bar(-1, 0);

	if(FTP_FileSize(name) != (int)siz)
		return false;
	return true;
}


void RomBK_new(char *name)
{

	sprintf(name, "%s_%s%02X.nds", GameTitle, Gamecode, RomVer);

	return;
}

