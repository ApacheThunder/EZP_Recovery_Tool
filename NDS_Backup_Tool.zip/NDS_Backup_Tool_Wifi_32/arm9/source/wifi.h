#ifndef _wIFI_INCLUDED
#define _wIFI_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include <dswifi9.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#define DB_DISCONNECTED 0

void *sgIP_malloc(int size);
void sgIP_free(void * ptr);

void initWifi();
void getWifiSync();

int wifiConnect(char *host, unsigned short port);
int wifiConnectIP(int mode, u32 ip, unsigned short port);
u32 ipToLong(char i1, char i2, char i3, char i4);
void sendData(int sock, char *data, int len);
int recvData(int sock, char *data, int len, int wait);

void disconnectWifi();
bool connectWifi();
bool isConnected();

void setBlocking(int sock);
void setNonBlocking(int sock);

#ifdef __cplusplus
}
#endif

#endif
