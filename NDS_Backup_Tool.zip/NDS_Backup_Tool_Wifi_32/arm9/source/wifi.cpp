#include <nds.h>
#include "wifi.h"

#include <stdlib.h>
#include <stdio.h>

#define IPC_CMD_WF_INIT 0xF0
#define IPC_CMD_WF_SYNC 0xF1

#define IPC_CMD9_WF_INIT 0xFFFFFFF0
#define IPC_CMD9_WF_SYNC 0xFFFFFFF1

//extern	u32	arm9fifo;


//#define REG_VCOUNT (*((u16 volatile *) 0x04000006))

#define WifiTimerInterval (50)

static bool wifiConnected = false;

void *sgIP_malloc(int size) 
{ 
	return malloc(size); 
}

void sgIP_free(void * ptr) 
{ 
	free(ptr); 
}

void Timer_ms(void) 
{
	Wifi_Timer(WifiTimerInterval);
}

void arm9_synctoarm7() 
{
	REG_IPC_FIFO_TX = IPC_CMD_WF_SYNC;
}

void arm9_fifo()
{
	u32 value = REG_IPC_FIFO_RX;

	if(value == IPC_CMD9_WF_SYNC)
		Wifi_Sync();
//	else	arm9fifo = value;
}


void initWifi()
{
	u32 Wifi_pass = Wifi_Init(WIFIINIT_OPTION_USELED);
	
	REG_IPC_FIFO_TX = IPC_CMD_WF_INIT;
	REG_IPC_FIFO_TX = Wifi_pass;
   	
	TIMER3_CR = 0;		// disable timer3
	
	irqSet(IRQ_TIMER3, Timer_ms); // setup timer IRQ
	irqEnable(IRQ_TIMER3);

	irqSet(IRQ_FIFO_NOT_EMPTY, arm9_fifo); // setup fifo IRQ
	irqEnable(IRQ_FIFO_NOT_EMPTY);

	REG_IPC_FIFO_CR = IPC_FIFO_ENABLE | IPC_FIFO_RECV_IRQ; // enable FIFO IRQ

   	Wifi_SetSyncHandler(arm9_synctoarm7); // tell wifi lib to use our handler to notify arm7

	TIMER_DATA(3) = -(131062 * WifiTimerInterval / 1000);
	TIMER_CR(3) = 0x00C2;
//	TIMER3_DATA = TIMER_FREQ_256(WifiTimerInterval);
//	TIMER3_CR = TIMER_ENABLE | TIMER_IRQ_REQ | TIMER_DIV_256;

	while(Wifi_CheckInit()==0) {	// wait for arm7 to be initted successfully
		swiWaitForVBlank();
	}

//  irqSet(IRQ_IPC_SYNC, Wifi_Update);
//  irqEnable(IRQ_IPC_SYNC);
//  REG_IPC_SYNC = IPC_SYNC_IRQ_ENABLE; 	


}

int wifiConnect(char *host, unsigned short port)
{
	int sock = 0;
	struct hostent	*tcp_he;
	struct sockaddr_in tcp_sain;
	
	tcp_he = gethostbyname(host);
	
	sock = socket(AF_INET,SOCK_STREAM,0);
	tcp_sain.sin_addr.s_addr = *((unsigned long *)(tcp_he->h_addr_list[0]));
	tcp_sain.sin_family = AF_INET;
	tcp_sain.sin_port = htons(port);
	
	setNonBlocking(sock);
	connect(sock, (struct sockaddr *)&tcp_sain, sizeof(tcp_sain));
	
	return sock;
}

void setBlocking(int sock)
{
	int i = 0;
    ioctl(sock, FIONBIO, &i); // set blocking
}

void setNonBlocking(int sock)
{
	int i = 1;
    ioctl(sock, FIONBIO, &i); // set non-blocking
}

void sendData(int sock, char *data, int len)
{
	int	ln;
	u32	p;
	vu32	vi;

	p = 0;
	ln = send(sock, data, len, 0);
	if(ln < len) {
		while(1) {
			if(ln > 0) {
				len -= ln;
				p += ln;
			}
			if(len <= 0)	break;

			for(vi = 0; vi < (u32)len * 150; vi++);	//====== dealy 1byte 0.025ms 375loop

			ln = send(sock, data + p, len, 0);
		}
	}
}

int recvData(int sock, char *data, int len, int wait)
{
	return recv(sock, data, len, 0);
}

int wifiConnectIP(int mode, u32 ip, unsigned short port)
{
	int sock = 0;
	struct sockaddr_in tcp_sain;
	
	sock = socket(AF_INET,SOCK_STREAM,0);
	tcp_sain.sin_addr.s_addr = ip;
	tcp_sain.sin_family = AF_INET;
	tcp_sain.sin_port = htons(port);

	if(mode == 0)
		setNonBlocking(sock);
	else	setBlocking(sock);
	connect(sock, (struct sockaddr *)&tcp_sain, sizeof(tcp_sain));
    
	return sock;
}

u32 ipToLong(char i1, char i2, char i3, char i4)
{
	u32 l;

	l = i1 | (i2 << 8) | (i3 << 16) | (i4 << 24);

	return l;
}

void disconnectWifi()
{
	if(!wifiConnected)
		return;
	
	wifiConnected = false;
	
	Wifi_DisconnectAP();
	Wifi_DisableWifi();
}

bool connectWifi()
{
	int i;

	if(wifiConnected)
		return true;

	Wifi_AutoConnect(); // request connect

	while(1) {
		swiWaitForVBlank();

		i = Wifi_AssocStatus(); // check status

//      char* animstr = "-\\|/";
//      static int anim = 0;
      
//      char indicator = animstr[anim];
//      anim++; if(anim>3) anim = 0;

      switch(i)
	{
	case ASSOCSTATUS_SEARCHING:
//	  setStatus(format("%c Searching for Access Point %c",
//			   indicator, indicator));
	  break;
	  
	case ASSOCSTATUS_AUTHENTICATING:
//	  setStatus(format("%c Authenticating %c",
//			   indicator, indicator));
	  break;
	  
	case ASSOCSTATUS_ASSOCIATING:
//	  setStatus(format("%c Associating %c",
//			   indicator, indicator));
	  break;
	  
	case ASSOCSTATUS_ACQUIRINGDHCP:
//	  setStatus(format("%c Acquiring DHCP %c",
//			   indicator, indicator));
	  break;
	  
	case ASSOCSTATUS_ASSOCIATED:
//	  setStatus("Connected");
	wifiConnected = true;
	  return true;
	  
	case ASSOCSTATUS_CANNOTCONNECT:
//	  setStatus("Could not connect");
	  Wifi_DisconnectAP();
	  return false;
	  
	default:
	  break;
	}
    }
  return false;
	
}

bool isConnected()
{
	return wifiConnected;
}
