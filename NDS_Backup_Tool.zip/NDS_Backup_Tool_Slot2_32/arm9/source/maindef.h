
#ifndef maindef_h
#define maindef_h

#define ROMTITLE "NDS Backup Tool Slot2"
#define ROMVERSION "Version 0.32 by Rudolph."
#define ROMDATE ""__DATE__" "__TIME__

#endif

