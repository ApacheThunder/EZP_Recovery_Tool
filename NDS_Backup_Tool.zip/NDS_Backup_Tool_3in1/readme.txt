====== NDS Backup Tool 3in1 V0.31 ======

Making use of 3in1 Expansion Pack, backup of the SAVE data of NDS ROM restore
And it is the tool which backs up ROM image.
Because you can think that trouble such that the SAVE data of NDS ROM breaks occurs
At self responsibility please utilize.
Starting the tool from [majikon] of Slot1, using NOR and SRAM of 3in1 Expansion Pack
Backup is drawn up in SD of Card of Slot1.


< Introduction method >
Because �gNDS_Backup_Tool_3in1.nds�h, it is DLDI correspondence, in combination with to Slot1 Card which is utilized
Please process the patch and the like. With default, it has become uninduced.

Adjusting �gNDS_Backup_Tool_3in1.ini�h to use environment with the editor, et. al it corrects.
In the route of SD, �gNDS_Backup_Tool_3in1.nds�h and �gNDS_Backup_Tool_3in1.ini�h are copied.
�@When there is no �gNDS_Backup_Tool_3in1.ini�h, it becomes operation at initial value, (usually it is not, the all right).

<NDS_Backup_Tool_3in1.ini>
Setting of various hardware requirements is entered. '#' and '!' Letter of after the line is handled as comment.
�@FileDir
�@�@�@Appoints the directory of SD which manages the file which it backs up (initial value /NDS_Backup).
�@SaveFile 0
�@�@�@When backing up SAVE of ROM, size of the SAV file is appointed. Size of the numerical value which it appoints
�@�@�@The unit becomes KByte. When 0 is appointed, it reaches the size of SAVE of ROM, (as for initial value, 0).
�@�@�@In case of R4/M3S 512, in case of DSLink please appoint 520.
�@Trim
�@�@�@When backing up NDS ROM, is appointed (as for initial value, there is no Trim when the trim it does the unused area).
�@NoEraseNor
�@�@�@After each backing up it does not eliminate NOR which is used. Usually, before writing the data to NOR, after eliminating
�@�@�@Because you write, as for elimination after the using it is not necessary, but it eliminates also after the processing for safety, (as for initial value, there is NOR elimination).


< Usage >
�gNDS_Backup_Tool_3in1�h is started.
With <L><R>, Save Backup Save Restore Rom Backup is changed.

�@(Save Backup)
�@<A>: It renews the contents of the SAV file which it appoints, with the contents of SAVE of ROM as backup.
�@<B>: Drawing up the new SAV file, it backs up the contents of SAVE of ROM.
�@�@�@�@�@Name of the SAV file which is drawn up automatically is GameTitle_Gamecode_No.sav.
�@�@�@�@�@No is calculated automatically to the 00-99.

�@(Save Restore)
�@<A>: Contents of the SAV file which it appoints, restore (entry) are done in SAVE of ROM.
�@<B>: The SAVE area of ROM is initialized with 0xFF.

�@(Rom Backup)
�@<A>: It renews with the contents where ROM dumps the contents of the NDS file which it appoints, as backup.
�@<B>: Drawing up the new NDS file, it backs up the contents which ROM dumps.
�@�@�@�@�@Name of the NDS file which is drawn up automatically is GameTitle_GamecodeRomVer.nds.
�@�@�@�@�@Already when there is a file of the same name, the upper book it is done automatically.

�@(Commonness)
�@<START>: Ending the program, it turns off the power of NDS.



< Note and the like >
In order to continue processing, the power source of DS is cut off automatically midway. That time, pulling out ROM, when starting you used
�@After difference changing into Card of Slot1, turning on the power of DS, please execute the tool for the second time.
While processing and continuation, when use same Card please (it modifies midway, be sure not to be able to continue processing).
As for Card of Slot1 and the removal pouring of ROM, following to the indication of the picture, please be sure to go.
While processing and continuation, please do not fumble the contents of SD of Card or the contents of the ini file.
Using �g3in1 Expansion Pack,�h SAVE of SRAM which was drawn up is guaranteed, but please evacuate in advance to make sure.
�@SAVE of SRAM which was drawn up with the other tool is not guaranteed. In addition, NOR is initialized.
ROM with the card, at one time there are times when you cannot recognize just (several degrees there are times when you can recognize by the fact that the removal pouring is done).
�@Macronix1024Mbit (128MB) and the like, please use the day Telecom �grecognition improvement adapter, or�h adjust the terminal of the basis.


< Flow of main processing >
(Save Backup)
�@1. At <A><B>, appointing the file which with backup it draws up & renews
�@2. In ROM which it backs up the difference changing
  3. Because the power source of DS is cut off automatically, difference changing into Card when starting, turning on the power of DS, starting the tool
�@4. With <A> processing continuation (actual file entry), discontinuing processing with <B>

�@(Save Restore)
�@1. At <A>, to appoint the file which it restores, with <B> initialization of the SAVE territory
�@2. In ROM which it restores the difference changing
�@3. The power source of DS is cut off automatically. Processing completion (has not used NOR of 3in1 at this point in time)

�@(Rom Backup)
�@1. At <A><B>, appointing the file which with backup it draws up & renews
�@2. In ROM which it backs up the difference changing
�@3. Because the power source of DS is cut off automatically, difference changing into Card when starting, turning on the power of DS, starting the tool
�@4. With <A> processing continuation (actual file entry), discontinuing processing with <B>
�@5. In case of ROM above 32MB, processing from 2 is repeated, (with 1 times in case of 32MB and 128MB 4 times)



< Past record >
V0.2  2007/8/17 Test edition. Drawing up 3in1 edition as a being defeated of Wifi/Slot-2 edition
V0.3  2007/8/19 Formal edition. Originally at the ini file appointing the presence of NOR elimination after the using which is not needed
V0.31 2008/1/29 It corresponded to the new 3in1 cart.

Furthermore 
====== the importance you ask, ====================================================================
As for use of the ROM image which it backs up, please limit to the utilization with the individual.
The ROM image which it backs up, please do not do behavior such as sale transfer distribution no matter what.
In addition, this tool is not something which promotes these irregularities.
===================================================================================================

by Rudolph

