
struct	bk_info {
		int	mode;		// 1:SaveBK, 2:RomBK
		u32	addr;		// Rom Addr
		u32	size;
		u32	tsiz;
		u32	GCode;
		char	name[32];
};

extern	struct	bk_info	bki;

#ifdef __cplusplus
extern "C" {
#endif

bool	SaveBK_1(int type, char *name);
bool	SaveBK_2();
bool	SaveBK_new(char *name);
bool	Save_Rest(char *name);
bool	Save_Init(void);
bool	RomBK_1(int type, char *name);
bool	RomBK_2();
bool	RomBK_new(char *name);

bool	checkFlashID(void);
int	checkSRAM(void);
void	set_bkinfo(void);


#ifdef __cplusplus
}
#endif
