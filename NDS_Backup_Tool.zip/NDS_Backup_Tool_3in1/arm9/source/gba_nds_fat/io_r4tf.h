#ifndef IO_R4TF_H
#define IO_R4TF_H

// 'R4TF'
#define DEVICE_TYPE_R4TF 0x46543452

#include "disc_io.h"

extern LPIO_INTERFACE R4TF_GetInterface(void);

#endif
