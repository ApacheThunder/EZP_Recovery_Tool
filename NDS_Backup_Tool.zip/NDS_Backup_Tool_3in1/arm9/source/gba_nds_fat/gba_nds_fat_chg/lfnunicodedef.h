static _VARS_IN_RAM Tunicode lfnNameUnicode[MAX_FILENAME_LENGTH];
