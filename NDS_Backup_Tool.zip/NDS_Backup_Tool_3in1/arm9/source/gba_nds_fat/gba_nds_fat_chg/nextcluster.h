
// read the nextCluster value
nextCluster = fatDumpBuffer[cluster];
