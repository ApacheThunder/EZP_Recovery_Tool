				// rawdata(Unicode)
				
				lfnNameUnicode[lfnPos + 0] = lfn.char0;
				lfnNameUnicode[lfnPos + 1] = lfn.char1;
				lfnNameUnicode[lfnPos + 2] = lfn.char2;
				lfnNameUnicode[lfnPos + 3] = lfn.char3;
				lfnNameUnicode[lfnPos + 4] = lfn.char4;
				lfnNameUnicode[lfnPos + 5] = lfn.char5;
				lfnNameUnicode[lfnPos + 6] = lfn.char6;
				lfnNameUnicode[lfnPos + 7] = lfn.char7;
				lfnNameUnicode[lfnPos + 8] = lfn.char8;
				lfnNameUnicode[lfnPos + 9] = lfn.char9;
				lfnNameUnicode[lfnPos + 10] = lfn.char10;
				lfnNameUnicode[lfnPos + 11] = lfn.char11;
				lfnNameUnicode[lfnPos + 12] = lfn.char12;
