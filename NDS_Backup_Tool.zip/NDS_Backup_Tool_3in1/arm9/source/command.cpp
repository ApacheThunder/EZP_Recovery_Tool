#include <nds.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//#include "ftp.h"
#include "CardRead.h"
#include "dsCard.h"
#include "disc_io.h"
#include "gba_nds_fat.h"

#include "cardme.h"
#include "command.h"
#include "sd.h"
#include "unicode.h"


extern	char	GameTitle[13];
extern	char	Gamecode[5];
extern	char	RomVer;
extern	u32	Devicecapacity;
extern	u32	UsedROMsize;
extern	u32	GCode;

extern	int	savetype;
extern	u32	savesize;

extern	int	numFiles;

extern	char	*romhead;
extern	char	*romsc1;
extern	char	*romsc2;



#define FAT_FT_END (0)
#define FAT_FT_FILE (1)
#define FAT_FT_DIR (2)


u8	savebuf[512];
char	fname[256];

//extern	u32	arm9fifo;
extern "C" {
	void err_cnf(int n1, int n2);
	int cnf_inp(int mode, int n1, int n2);
	void dsp_bar(int mod, int per);
	bool set_rom(void);
}

/***********
void Save_read()
{

	u32	add;


	for(add = 0; add < savesize; add += 512) {
		cardmeReadEeprom(add, (u8*)romsc2 + add, 512, savetype); 
	}

	return;
}
***********/

bool SaveBK_1(int type, char *name)
{
	int	per;
	u32	siz;
	u32	i;

	if(type == 0) {
		while(1) {
			if(set_rom() == false)
				return false;
			if(savetype < 1)
				err_cnf(13, 6);
			else	break;
		}
	}

	siz = ini.save * 1024;
	if(siz < savesize)
		siz = savesize;

	bki.mode = 1;
	bki.addr = 0;
	bki.size = 0;
	bki.tsiz = siz;
	strcpy(bki.name, name);

	dsp_bar(5, -1);

	SetRompage(0);
	OpenNorWrite();
	SetSerialMode();
	for(siz = 0; siz < bki.tsiz; siz += 0x40000) {
		per = (siz * 100) / bki.tsiz;
		if(bki.tsiz <= 0x20000)	per = 50;
		dsp_bar(5, per);
	        Block_Erase(siz);
	}
	dsp_bar(5, 100);
	chip_reset();

	dsp_bar(-1, 0);

	dsp_bar(6, -1);

	SetRompage(0);
	OpenNorWrite();
	SetSerialMode();

	for(bki.size = 0; bki.size < bki.tsiz; bki.size += 0x4000) {
		memset((char *)romsc2, 0xFF, 0x4000);
		per = (bki.size * 100) / bki.tsiz;
		dsp_bar(6, per);

		for(i = 0; i < 0x4000; i += 512) {
			if(bki.size + i < savesize)
				cardmeReadEeprom(bki.size + i, (u8*)(romsc2 + i), 512, savetype); 
		}

		WriteNorFlash(bki.size, (u8*)romsc2, 0x4000);
	}
	dsp_bar(6, 100);
	CloseNorWrite();

	set_bkinfo();
	dsp_bar(-1, 0);

	err_cnf(11, 12);
//	turn_off(0);
	return true;
}


bool SaveBK_2()
{
	FAT_FILE	*savFile;
	int	per;
	u32	siz;


	dsp_bar(0, -1);

	sprintf(fname, "%s/%s", ini.dir, bki.name);
	savFile = FAT_fopen(fname, "wb");
	if(savFile == NULL) {
		dsp_bar(-1, 0);
		return false;
	}


	SetRompage(0);
	OpenNorWrite();
	SetSerialMode();

	for(bki.size = 0; bki.size < bki.tsiz; bki.size += 512) {
		ReadNorFlash(savebuf, bki.size, 512);
		per = (bki.size * 100) / bki.tsiz;
		dsp_bar(0, per);

		FAT_fwrite((char *)savebuf, 512, 1, savFile);
	}
	dsp_bar(0, 100);

	FAT_fclose(savFile);
	CloseNorWrite();
	dsp_bar(-1, 0);

	bki.mode = 0;
	bki.addr = 0;
	bki.size = 0;
	bki.tsiz = 0;
	bki.GCode = 0;
	bki.name[0] = 0;
	set_bkinfo();

	if(ini.noerase == 0)	return true;

	dsp_bar(5, -1);
	SetRompage(0);
	OpenNorWrite();
	SetSerialMode();
	for(siz = 0; siz < bki.tsiz; siz += 0x40000) {
		per = (siz * 100) / bki.tsiz;
		if(bki.tsiz <= 0x20000)	per = 50;
		dsp_bar(5, per);
	        Block_Erase(siz);
	}
	dsp_bar(5, 100);
	chip_reset();
	CloseNorWrite();

	dsp_bar(-1, 0);

	return true;
}


extern "C" {
extern void ShinoPrint_SUB( uint16* screen, int x, int y, u8 *st, u16 Fpalet, u16 Bpalet, u8 kaki );
extern	u32 inp_key();
}
extern uint16* SubScreen;


bool SaveBK_new(char *name)
{

	int	no;
	int	i;

	while(1) {
		if(set_rom() == false)
			return false;
		if(savetype < 1)
			err_cnf(13, 6);
		else	break;
	}

	dsp_bar(2, -2);

	for(no = 0; no < 100; no++) {
		sprintf(name, "%s_%s_%02d.sav", GameTitle, Gamecode, no);

//		sprintf(fname, "%s/%s", ini.dir, name);
//		if(FAT_FileExists(fname) != FAT_FT_FILE)

		for(i = 0; i < numFiles; i++) {
			Unicode2Local(fs[i].uniname, (u8*)fname, 24);
			if(strcmp(fname, name) == 0)
				break;
		}
		if(i >= numFiles)	break;
	}

	if(no == 100)	no = 0;
	sprintf(name, "%s_%s_%02d.sav", GameTitle, Gamecode, no);

	dsp_bar(-1, 0);

	return true;
}

/***
extern "C" {
extern void ShinoPrint_SUB( uint16* screen, int x, int y, u8 *st, u16 Fpalet, u16 Bpalet, u8 kaki );
extern	u32 inp_key();
}
extern uint16* SubScreen;
***/


bool Save_Rest(char *name)
{

	FAT_FILE	*savFile;
//	int	ret;
	u32	add;
	int	per;
	int	len;
	u32	siz;

	sprintf(fname, "%s/%s", ini.dir, name);
	savFile = FAT_fopen(fname, "rb");
	if(savFile == NULL) {
//		dsp_bar(-1, 0);
		return false;
	}

	siz = FAT_fread((char *)romsc2, 512 * 1024, 1, savFile);

/***
	for(add = 0; add < savesize; ) {
//		per = (add * 100) / savesize;
//		dsp_bar(1, per);
		len = savesize - add;
		if(len > 512)	len = 512;
		len = FAT_fread((char *)(romsc2 + add), len, 1, savFile);
		add += len;
	}
//	dsp_bar(1, 100);
***/
	FAT_fclose(savFile);
//	dsp_bar(-1, 0);

	while(1) {
		if(set_rom() == false)
			return false;

		if(savetype < 1) {
			err_cnf(13, 6);
			continue;
		}
		if(siz < savesize) {
			err_cnf(9, 10);
			continue;
		}
		break;
	}

	if(savetype == 3) {
		dsp_bar(3, -1);
		for(add = 0; add < savesize; add += 0x10000) {
			per = (add * 100) / savesize;
			dsp_bar(3, per);
			cardmeSectorErase(add);
		}
		dsp_bar(-1, 0);
	}

	dsp_bar(1, -1);
	for(add = 0; add < savesize; ) {
		per = (add * 100) / savesize;
		dsp_bar(1, per);
		len = savesize - add;
		if(len > 512)	len = 512;
		cardmeWriteEeprom(add, (u8*)(romsc2 + add), len, savetype);
		add += len;
	}
	dsp_bar(1, 100);
	dsp_bar(-1, 0);

	err_cnf(11, 12);

	return true;
}


bool Save_Init()
{

	u32	add;
	int	per;
	int	len;


	while(1) {
		if(set_rom() == false)
			return false;
		if(savetype < 1)
			err_cnf(13, 6);
		else	break;
	}

	if(savetype == 3) {
		dsp_bar(3, -1);
		for(add = 0; add < savesize; add += 0x10000) {
			per = (add * 100) / savesize;
			dsp_bar(3, per);
			cardmeSectorErase(add);
		}
		dsp_bar(3, 100);
		dsp_bar(-1, 0);
		return true;
	}

	dsp_bar(3, -1);
	memset((char *)savebuf, 0xFF, 512);
	for(add = 0; add < savesize; ) {
		per = (add * 100) / savesize;
		dsp_bar(3, per);
		len = savesize - add;
		if(len > 512)	len = 512;
		cardmeWriteEeprom(add, savebuf, len, savetype);
		add += len;
	}
	dsp_bar(3, 100);
	dsp_bar(-1, 0);

	return true;
}



bool RomBK_1(int type, char *name)
{
	int	per;
	u32	siz;
	u32	add, of;


	if(type == 0) {
		while(1) {
			if(set_rom() == false)
				return false;
			if((bki.mode == 0) || (bki.GCode == GCode))
				break;
			err_cnf(5, 6);
		}
	}

	dsp_bar(5, -1);

	if(bki.mode == 0) {
		siz = Devicecapacity;
		if(ini.trim != 0) {
			siz = UsedROMsize;
			siz = ((siz + 511 + 136) / 512) * 512;
		}

		bki.mode = 2;
		bki.addr = 0;
		bki.size = 0;
		bki.GCode = GCode;
		bki.tsiz = siz;
		strcpy(bki.name, name);
	}

	siz = bki.tsiz - bki.addr;
	if(siz > 32 * 1024 * 1024)
		siz = 32 * 1024 * 1024;
//	if(siz > 8 * 1024 * 1024)
//		siz = 8 * 1024 * 1024;


	SetRompage(0);
	OpenNorWrite();
	SetSerialMode();
	for(add = 0; add < siz; add += 0x40000) {
		per = (add * 100) / siz;
		dsp_bar(5, per);
	        Block_Erase(add);
	}
	dsp_bar(5, 100);
	chip_reset();
	CloseNorWrite();
	dsp_bar(-1, 0);



	dsp_bar(6, -1);
//	SetRompage(0);
	OpenNorWrite();
	SetSerialMode();

	bki.size = 0x0;
	add = bki.addr;
	if(add == 0) {
		memcpy(romsc2, romhead, 0x200);
		memset(romsc2 + 0x200, 0x00, 0x3E00);
		memcpy(romsc2 + 0x4000, romsc1, 0x4000);

/********
		per = 0x4000 / siz;
	dsp_bar(0, 1);
		WriteNorFlash(0, (u8*)romhead, 512);
		memset((char *)romsc2, 0x00, 0x3E00);
		WriteNorFlash(512, (u8*)romsc2, 0x3E00);

		per = 0x8000 / siz;
*********/
		dsp_bar(6, 0);
		WriteNorFlash(0, (u8*)romsc2, 0x8000);
		add = 0x8000;
		bki.size = 0x8000;
	}

	for(; bki.size < siz; bki.size += 0x8000) {
		for(of = 0; of < 0x8000; of += 512) {
			Read_Data((u8*)(romsc2 + of), add);
			add += 512;
		}
		per = (bki.size * 100) / siz;
		dsp_bar(6, per);

		WriteNorFlash(bki.size, (u8*)romsc2, 0x8000);
	}
	dsp_bar(6, 100);

	CloseNorWrite();

	set_bkinfo();
	dsp_bar(-1, 0);

	err_cnf(11, 12);
//	turn_off(0);
	return true;
}



bool RomBK_2()
{
	FAT_FILE	*savFile;
	u32	add;
	int	per;
	u32	siz;

	dsp_bar(4, -1);


	sprintf(fname, "%s/%s", ini.dir, bki.name);
	if(bki.addr == 0)
		savFile = FAT_fopen(fname, "wb");
	else	savFile = FAT_fopen(fname, "r+b");
	if(savFile == NULL) {
		dsp_bar(-1, 0);
		return false;
	}
	FAT_fseek(savFile, 0, SEEK_END);


	SetRompage(0);
	OpenNorWrite();
	SetSerialMode();

	for(add = 0; add < bki.size; add += 0x4000) {
		siz = bki.size - add;
		if(siz > 0x4000)	siz = 0x4000;
		ReadNorFlash((u8*)romsc2, add, siz);
		per = (add * 100) / bki.size;
		dsp_bar(4, per);

		FAT_fwrite(romsc2, siz, 1, savFile);
	}
	dsp_bar(4, 100);
	CloseNorWrite();

	FAT_fclose(savFile);
	dsp_bar(-1, 0);

	if(bki.addr + bki.size >= bki.tsiz) {
		if(ini.noerase == 0) {
			dsp_bar(5, -1);
			SetRompage(0);
			OpenNorWrite();
			SetSerialMode();
			for(add = 0; add < bki.size; add += 0x40000) {
				per = (add * 100) / bki.size;
				dsp_bar(5, per);
			        Block_Erase(add);
			}
			dsp_bar(5, 100);
			chip_reset();
			CloseNorWrite();
			dsp_bar(-1, 0);
		}
		bki.mode = 0;
		bki.addr = 0;
		bki.size = 0;
		bki.GCode = 0;
		bki.tsiz = 0;
		bki.name[0] = 0;
	} else {
		bki.addr += bki.size;
		bki.size = 0;
	}
	set_bkinfo();

//	if(bki.mode != 0)
//		return(RomBK_1(0, bki.name));

FAT_FreeFiles();

	return true;
}


bool RomBK_new(char *name)
{

	if(set_rom() == false)
		return false;

	sprintf(name, "%s_%s%02X.nds", GameTitle, Gamecode, RomVer);

	return true;
}

