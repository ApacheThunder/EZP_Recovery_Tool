
#ifndef maindef_h
#define maindef_h

#define ROMTITLE "NDS Backup Tool 3in1"
#define ROMVERSION "Version 0.31 by Rudolph."
#define ROMDATE ""__DATE__" "__TIME__

#endif

