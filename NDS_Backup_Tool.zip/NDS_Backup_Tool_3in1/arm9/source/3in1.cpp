#include <nds.h>
//#include <fat.h>
//#include <sys/dir.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>

#include "disc_io.h"
#include "gba_nds_fat.h"
#define FAT_FT_END (0)
#define FAT_FT_FILE (1)
#define FAT_FT_DIR (2)

#include "unicode.h"
#include "command.h"


//#include <nds/registers_alt.h>
//#include <nds/arm9/rumble.h>

#include "dsCard.h"

//#include <nds/arm9/console.h> //basic print funcionality

#define MAX_NOR		0x2000000 	// 32MByte 
#define MAX_PSRAM	0x1000000 	// 16MByte 
#define SRAM_PAGE_SIZE	0x1000	  	// SRAM Page Size
#define MAX_SRAM	0x80000		// 4MBit/512KByte total SRAM

#define	SRAM_ADDR	0x0A000000
#define	USE_SRAM	0x20000		// 128KByte
#define	USE_SRAM_NOR	16		// 0x0A010000-0A02FFFF
#define	USE_SRAM_PG	48		// 0x0A030000-0A031FFF
#define	USE_SRAM_PSR	50		// 0x0A032000-0A051FFF

#define PSRAM_BUF	0x8000		// 32KB


struct	bk_info	bki;

extern	char	tbuf[];


bool checkFlashID()
{
	OpenNorWrite();
	uint32 id = ReadNorFlashID();
	chip_reset();
	CloseNorWrite();

	if(id == 0)
		return false;

	return true;
}


char	*Rudolph = "3in1 Expansion Pack Tool by Rudolph (Unicode v0.1)";
char	*Backup = "NDS Backup Tool 3ini";

int checkSRAM()
{
	u16	buf[256];
	int	i;

	bki.mode = 0;
	bki.size = 0;
	bki.tsiz = 0;
	bki.GCode = 0;
	bki.name[0] = 0;

	OpenNorWrite();
	SetRampage(USE_SRAM_PG);

	ReadSram(SRAM_ADDR, (u8*)tbuf, 256);
	for(i = 0; tbuf[i] != 0; i++) {
		if(tbuf[i] != Rudolph[i])
			break;
	}
	if(Rudolph[i] != 0) {
		memset(tbuf, 0, 256);
		sprintf(tbuf, Rudolph);
		WriteSram(SRAM_ADDR, (u8*)tbuf, 256);
		memset((u8*)buf, 0, 512);
		WriteSram(SRAM_ADDR + 256, (u8*)buf, 512);
		WriteSram(SRAM_ADDR + 768, (u8*)buf, 512);

		memset(tbuf, 0, 256);
		sprintf(tbuf, Backup);
		WriteSram(SRAM_ADDR + 1024, (u8*)tbuf, 256);
		WriteSram(SRAM_ADDR + 1024 + 256, (u8*)tbuf, 256);

		CloseNorWrite();
		return false;
	}


	ReadSram(SRAM_ADDR + 1024, (u8*)tbuf, 256);
	for(i = 0; tbuf[i] != 0; i++) {
		if(tbuf[i] != Backup[i])
			break;
	}
	if(Backup[i] != 0) {
		memset(tbuf, 0, 256);
		sprintf(tbuf, Backup);
		WriteSram(SRAM_ADDR + 1024, (u8*)tbuf, 256);
		WriteSram(SRAM_ADDR + 1024 + 256, (u8*)tbuf, 256);
		CloseNorWrite();
		return false;
	}


	ReadSram(SRAM_ADDR + 1024 + 256, (u8*)(&bki), sizeof(struct bk_info));
	CloseNorWrite();
	return true;
}

void set_bkinfo()
{
	OpenNorWrite();
	SetRampage(USE_SRAM_PG);

	WriteSram(SRAM_ADDR + 1024 + 256, (u8*)(&bki), sizeof(struct bk_info));

	CloseNorWrite();
}

