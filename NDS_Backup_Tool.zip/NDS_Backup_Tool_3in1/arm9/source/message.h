
extern	char	*errmsg[];
extern	char	*cnfmsg[];
extern	char	*barmsg[];
extern	char	*t_msg[];
extern	char	*stsmsg[];


#ifdef __cplusplus
extern "C" {
#endif

extern	void	setLangMsg(void);

#ifdef __cplusplus
}
#endif
