#ifndef _LIBCARDDUMP_H_
#define _LIBCARDDUMP_H_

#ifdef __cplusplus
extern "C" {
#endif

u32 Card_Open(char *key_tbl);		// Card recognition and initialization of card dump.
u32 Card_Retry(void);			// Recognizing of card retry.

bool Card_Read(u32 addr, char *data);	// Card dump of specified address(512*n)

bool Card_Close(void);			// End of card dump

#ifdef __cplusplus
}
#endif

#endif	// _LIBCARDDUMP_H_
