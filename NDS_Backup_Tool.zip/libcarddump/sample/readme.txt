All is not supported. Please do not inquire.

build devkitARM_r26(libnds 1.3.8).
