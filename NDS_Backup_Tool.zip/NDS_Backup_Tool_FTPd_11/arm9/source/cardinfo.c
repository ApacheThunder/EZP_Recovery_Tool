#include <nds.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "ftpd_cmd.h"
#include "ftpd.h"


extern	char	GameTitle[13];
extern	char	Gamecode[5];
extern	char	RomVer;
extern	u32	Devicecapacity;
extern	u32	UsedROMsize;
extern	u32	romID;

extern	int	savetype;
extern	int	nosupport;
extern	u32	savesize;
extern	u8	flashID[3];

extern	char	*romhead;
extern	char	*info;


static int _info_set()
{
	int	sz = 0;

	sprintf(info + sz, "< ROM Information >\r\n");
	sz = strlen(info);

	sprintf(info + sz, "\tGame Title : %s\r\n", GameTitle);
	sz = strlen(info);
	sprintf(info + sz, "\t      Code : NTR-%s   Ver : %02X\r\n", Gamecode, RomVer);
	sz = strlen(info);
	sprintf(info + sz, "\tMaker Code : %c%c   Unit Code : %02X\r\n", romhead[0x10], romhead[0x11], romhead[0x12]);
	sz = strlen(info);

	sprintf(info + sz, "\t   Chip ID : %02X %02X %02X %02X\r\n", romID & 0xFF, (romID >> 8) & 0xFF, (romID >> 16) & 0xFF, (romID >> 24) & 0xFF);
	sz = strlen(info);
	sprintf(info + sz, "\t  ROM Size : %dM (%dMByte)  Used : %6.2fMByte\r\n", Devicecapacity / (1024*128), Devicecapacity / (1024*1024), (float)UsedROMsize / (1024*1024));
	sz = strlen(info);

	sprintf(info + sz, "\r\n< SAVE Information >\r\n");
	sz = strlen(info);

	if(savetype == -1)
		sprintf(info + sz, "\tSAVE Type : Not provide\r\n");
	if(savetype == 0)
		sprintf(info + sz, "\tSAVE Type : Unknown\r\n");
	if(savetype == 1)
		sprintf(info + sz, "\tSAVE Type : EEPROM %dK (%dByte)\r\n", savesize / (1024/8), savesize);
	if(savetype == 2)
		sprintf(info + sz, "\tSAVE Type : EEPROM %dK (%dKByte)\r\n", savesize / (1024/8), savesize / 1024);
	if(savetype == 3) {
		if(nosupport)
			sprintf(info + sz, "\tSAVE Type : No Support %dM\r\n", savesize / (1024*1024/8));
		else	sprintf(info + sz, "\tSAVE Type : FLASH %dM (%dKByte)\r\n", savesize / (1024*1024/8), savesize / 1024);
	}
	sz = strlen(info);

	if(savetype == 3) {
		sprintf(info + sz, "\t FLASH ID : %02X %02X %02X\r\n", flashID[0], flashID[1], flashID[2]);
		sz = strlen(info);
	}

	sprintf(info + sz, "\r\n\r\n\r\n$ from NDS Backup Tool FTPd v0.1\r\n");
	sz = strlen(info);

	return(sz);
}

int card_info()
{
	u32 siz;

	time_t unixTime = time(NULL);
	struct tm* TS = gmtime((const time_t *)&unixTime);
	int cnt = 0;

	fs[cnt].lay = 0;
	fs[cnt].type = 0;		// 0:dir, 1:nds, 2:sav, 3:file
	sprintf(fs[cnt].filename, "%s_%s_%02X", GameTitle, Gamecode, RomVer);
	fs[cnt].filesize = 0;
	fs[cnt].year = TS->tm_year;		// - 1900
	fs[cnt].month = TS->tm_mon;
	fs[cnt].day = TS->tm_mday;
	fs[cnt].hh = TS->tm_hour;
	fs[cnt].mm = TS->tm_min;
	fs[cnt].ss = TS->tm_sec;
	cnt++;

	fs[cnt].lay = 1;
	fs[cnt].type = 1;		// 0:dir, 1:nds, 2:sav, 3:file
	sprintf(fs[cnt].filename, "%s_%s.nds", GameTitle, Gamecode);
	fs[cnt].filesize = Devicecapacity;
	fs[cnt].year = TS->tm_year;		// - 1900
	fs[cnt].month = TS->tm_mon;
	fs[cnt].day = TS->tm_mday;
	fs[cnt].hh = TS->tm_hour;
	fs[cnt].mm = TS->tm_min;
	fs[cnt].ss = TS->tm_sec;
	cnt++;

	if(savetype > 0) {
		fs[cnt].lay = 1;
		fs[cnt].type = 2;		// 0:dir, 1:nds, 2:sav, 3:file
		sprintf(fs[cnt].filename, "%s_%s.sav", GameTitle, Gamecode);

		siz = ini.save * 1024;
		if(siz < savesize)
			siz = savesize;
		fs[cnt].filesize = siz;

		fs[cnt].year = TS->tm_year;		// - 1900
		fs[cnt].month = TS->tm_mon;
		fs[cnt].day = TS->tm_mday;
		fs[cnt].hh = TS->tm_hour;
		fs[cnt].mm = TS->tm_min;
		fs[cnt].ss = TS->tm_sec;
		cnt++;
	}


	fs[cnt].lay = 1;
	fs[cnt].type = 3;		// 0:dir, 1:nds, 2:sav, 3:file
	sprintf(fs[cnt].filename, "%s_%s.txt", GameTitle, Gamecode);
	fs[cnt].filesize = _info_set();
	fs[cnt].year = TS->tm_year;		// - 1900
	fs[cnt].month = TS->tm_mon;
	fs[cnt].day = TS->tm_mday;
	fs[cnt].hh = TS->tm_hour;
	fs[cnt].mm = TS->tm_min;
	fs[cnt].ss = TS->tm_sec;
	cnt++;

	return(cnt);
}
