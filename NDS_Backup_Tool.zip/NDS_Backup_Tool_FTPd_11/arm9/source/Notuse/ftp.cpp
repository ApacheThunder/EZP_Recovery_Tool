#include <nds.h>
#include <fat.h>
#include "wifi.h"


#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "ftp.h"


#include "tarosa/tarosa_Graphic.h"
#include "tarosa/tarosa_Shinofont.h"
extern uint16* SubScreen;

//#ifdef __cplusplus
//extern "C" {
//#endif
//extern u32 inp_key();
//#ifdef __cplusplus
//}
//#endif



int	rwmode = 0;
//u32	sendrem;



struct	ini_file	ini;
struct	FTP_File	fs[200];

int	sock_cmd = -1;
int	sock_data = -1;


char	*ftpbuf;
char	*resdata;
char	*senddata;


#define	FTPBUFSIZE	1024
#define	RECVWAIT	500		// 4sec (4ms*1000)

//extern u32	_io_dldi;

void FTP_ini()
{
	FILE	*ftpini;
	int	len, p, s;
	char	key[20];

	ftpbuf = (char *)malloc(FTPBUFSIZE);
	resdata = (char *)malloc(FTPBUFSIZE);
	senddata = (char *)malloc(FTPBUFSIZE);

	ini.sv_ip[0] = 192;
	ini.sv_ip[1] = 168;
	ini.sv_ip[2] = 0;
	ini.sv_ip[3] = 10;
	ini.port = 21;
	ini.dir[0] = 0;
	strcpy(ini.user, "anonymous");
	strcpy(ini.pass, "anonymous@anonymous");
	ini.save = 0;
	ini.trim = 0;

//	if(_io_dldi == 0)	return;

	ftpini = fopen("/NDS_Backup_Tool_Wifi.ini", "rb");
	if(ftpini == NULL)	return;

	len = fread(ftpbuf, 1, FTPBUFSIZE, ftpini);

	p = 0;
	while(p < len) {
		if(ftpbuf[p] == '#' || ftpbuf[p] == '!') {
			while(p < len) {
				if(ftpbuf[p] == 0x0A)
					break;
				p++;
			}
			p++;
		}

		s = 0;
		while(ftpbuf[p] >= 0x20 && ftpbuf[p] < 0x7F) {
			key[s] = ftpbuf[p];
			s++;
			p++;
		}
		key[s] = 0;

		if(strcmp(key, "ServerIP") == 0) {
			while(p < len) {
				if(ftpbuf[p] >= 0x30 && ftpbuf[p] <= 0x39)
					break;
				p++;
			}
			s = 0;
			ini.sv_ip[0] = ini.sv_ip[1] = ini.sv_ip[2] = ini.sv_ip[3] = 0;
			while(p < len) {
				if(ftpbuf[p] >= 0x30 && ftpbuf[p] <= 0x39)
					ini.sv_ip[s] = ini.sv_ip[s] * 10 + ftpbuf[p] - 0x30;
				else 	s++;
				if(s >= 4)	break;
				p++;
			}
		}
		if(strcmp(key, "ServerPort") == 0) {
			ini.port = 0;
			while(p < len) {
				if(ftpbuf[p] >= 0x30 && ftpbuf[p] <= 0x39)
					break;
				p++;
			}
			while(p < len) {
				if(ftpbuf[p] < 0x30 || ftpbuf[p] > 0x39)
					break;
				ini.port = ini.port * 10 + ftpbuf[p] - 0x30;
				p++;
			}
		}
		if(strcmp(key, "FileDir") == 0) {
			s = 0;
			while(p < len) {
				if(ftpbuf[p] == 0x20 || ftpbuf[p] == '\t')
					p++;
				else	break;
			}
			while(p < len) {
				if(ftpbuf[p] <= 0x20 || ftpbuf[p] >= 0x7F)
					break;
				if(s < 63)
					ini.dir[s] = ftpbuf[p];
				s++;
				p++;
			}
			ini.dir[s] = 0;
		}

		if(strcmp(key, "FTPUser") == 0) {
			s = 0;
			while(p < len) {
				if(ftpbuf[p] == 0x20 || ftpbuf[p] == '\t')
					p++;
				else	break;
			}
			while(p < len) {
				if(ftpbuf[p] <= 0x20 || ftpbuf[p] >= 0x7F)
					break;
				if(s < 31)
					ini.user[s] = ftpbuf[p];
				s++;
				p++;
			}
			ini.user[s] = 0;
		}
		if(strcmp(key, "FTPPassword") == 0) {
			s = 0;
			while(p < len) {
				if(ftpbuf[p] == 0x20 || ftpbuf[p] == '\t')
					p++;
				else	break;
			}
			while(p < len) {
				if(ftpbuf[p] <= 0x20 || ftpbuf[p] >= 0x7F)
					break;
				if(s < 31)
					ini.pass[s] = ftpbuf[p];
				s++;
				p++;
			}
			ini.pass[s] = 0;
		}
		if(strcmp(key, "SaveFile") == 0) {
			ini.save = 0;
			while(p < len) {
				if(ftpbuf[p] >= 0x30 && ftpbuf[p] <= 0x39)
					break;
				p++;
			}
			while(p < len) {
				if(ftpbuf[p] < 0x30 || ftpbuf[p] > 0x39)
					break;
				ini.save = ini.save * 10 + ftpbuf[p] - 0x30;
				p++;
			}
		}
		if(strcmp(key, "Trim") == 0) {
			ini.trim = 1;
		}

		while(p < len) {
			p++;
			if(ftpbuf[p - 1] == 0x0A)
				break;
		}
	}

	fclose(ftpini);

	if(ini.dir[0] != '/')
		ini.dir[0] = 0;

}


/***************
extern "C" {
extern void ShinoPrint_SUB( uint16* screen, int x, int y, u8 *st, u16 Fpalet, u16 Bpalet, u8 kaki );
}
extern uint16* SubScreen;

*********/

int _resp_check()
{
	int	errcnt;
	int	cmd, len;
	int	p, ph;
	int	res;
//	vu32	vi;

	cmd = res = 0;
	ph = 1;
	errcnt = 0;
	while(1) {
		len = recvData(sock_cmd, ftpbuf, FTPBUFSIZE, 0);
		if(len <= 0)	errcnt++;
		if(errcnt >= RECVWAIT)	return(-1);

		p = 0;
		while(p < len) {
			switch(ph) {
				case 0:
					if(ftpbuf[p] == 0x0A)
						ph++;
					break;
				case 1:
					cmd = 0;
				case 2:
				case 3:
					if(ftpbuf[p] >= 0x30 && ftpbuf[p] <= 0x39) {
						cmd = cmd * 10 + ftpbuf[p] - 0x30;
						ph++;
					} else	ph = 0;
					break;
				case 4:
					if(ftpbuf[p] == ' ') {
						ph++;
						res = 0;
					} else	ph = 0;
					break;
				case 5:
					resdata[res] = ftpbuf[p];
					res++;
					if(ftpbuf[p] == 0x0A)
						ph++;
					break;
			}
			if(ph == 6)	break;
			p++;
		}
		if(ph == 6)	break;

//		for(vi = 0; vi < 100*400; vi++)
		swiWaitForVBlank();

	}

	resdata[res] = 0;


//	sprintf(ftpbuf, "%d %s", cmd, resdata);
//	ftpbuf[40] = 0;
//	ShinoPrint_SUB( SubScreen, 2*6, 7*12+6, (u8 *)ftpbuf, 1, 0, 1);

	return(cmd);
}




bool pasv_mod()
{
	u32	p_ip, p_port;
	int	len;
	int	i, p, f;
	u8	d[6];

	sprintf(ftpbuf, "PASV\r\n");
	sendData(sock_cmd, ftpbuf, strlen(ftpbuf));

	for(p = 0; p < 6; p++)
		d[p] = 0;
	p = f = i = 0;

	if(_resp_check() != 227)
		return false;

	len = strlen(resdata);
	while(i < len) {
		if(f) {
			if(resdata[i] >= 0x30 && resdata[i] <= 0x39)
				d[p] = d[p] * 10 + resdata[i] - 0x30;
			if(resdata[i] == ',')
				p++;
			if(resdata[i] == ')')
				break;
		} else {
			if(resdata[i] == '(')
				f = 1;
		}
		i++;
	}

	if(p != 5)	return false;

	p_ip = ipToLong(d[0], d[1], d[2], d[3]);
	p_port = d[4] * 256 + d[5];

/******
	sprintf(resdata, "                           ");
	ShinoPrint_SUB( SubScreen, 5*6, 7*12, (u8 *)resdata, 1, 0, 0);
	sprintf(resdata, "IP = %d %d %d %d (%d)", d[0],d[1],d[2],d[3],p_port);
	ShinoPrint_SUB( SubScreen, 5*6, 7*12, (u8 *)resdata, 1, 0, 1);
*****/

//	if(rwmode == 0)
		sock_data = wifiConnectIP(1, p_ip, p_port);
//	else	sock_data = wifiConnectIP(0, p_ip, p_port);

	return true;
}



bool FTP_Login()
{
	u32	ip;
	int	cmd;
	vu32	vi;

 	ip = ipToLong(ini.sv_ip[0], ini.sv_ip[1], ini.sv_ip[2], ini.sv_ip[3]);

	sock_cmd = wifiConnectIP(0, ip, ini.port);	// non block

	for(vi = 0; vi < 40; vi++)	// 500ms
		swiWaitForVBlank();

	cmd = _resp_check();
	if(cmd <= 0)
		cmd = _resp_check();
	if(cmd != 220)
		return false;

	sprintf(ftpbuf, "USER %s\r\n", ini.user);
	sendData(sock_cmd, ftpbuf, strlen(ftpbuf));
	if(_resp_check() != 331)
		return false;


	sprintf(ftpbuf, "PASS %s\r\n", ini.pass);
	sendData(sock_cmd, ftpbuf, strlen(ftpbuf));
	if(_resp_check() != 230)
		return false;


	if(ini.dir[0] != 0) {
		sprintf(ftpbuf, "CWD %s\r\n", ini.dir);
		sendData(sock_cmd, ftpbuf, strlen(ftpbuf));
		if(_resp_check() != 250)
			return false;
	}


	return true;
}

bool FTP_Logoff()
{
	vu32	vi;


	recvData(sock_cmd, ftpbuf, FTPBUFSIZE, 0);

	sprintf(ftpbuf, "QUIT\r\n");
	sendData(sock_cmd, ftpbuf, strlen(ftpbuf));
	for(vi = 0; vi < 20; vi++)	// 250ms
		swiWaitForVBlank();

//	_resp_check();

	shutdown(sock_cmd, SHUT_WR);
	for(vi = 0; vi < 20; vi++)	// 250ms
		swiWaitForVBlank();

	closesocket(sock_cmd);

	return true;
}


bool _set_fs(int no, char *name)
{
	int	p, s;
	int	p1, p2;

	for(p = 0; name[p] != 0; p++) {
		if(name[p] == ':')	break;
	}

	if(name[p] != ':')	return false;

	p1 = p - 11;
	p2 = p + 4;

	for(p = p1; p >= 0; p--) {
		if(name[p] < 0x30 || name[p] > 0x39)
			break;
	}

	fs[no].filesize = 0;
	for(p++; p <= p1; p++)
		fs[no].filesize = fs[no].filesize * 10 + name[p] - 0x30;

	s = 0;
	for(p = p2; name[p] >= 0x20; p++) {
		fs[no].filename[s] = name[p];
		s++;
	}
	fs[no].filename[s] = 0;

	return true;
}



int FTP_FileList(char *wild)
{
	char	file[256];
	int	num = 0;
	int	len, p, s;
	char	bc;
	int	fin;


	recvData(sock_cmd, ftpbuf, FTPBUFSIZE, 0);

	sprintf(ftpbuf, "TYPE A\r\n");
	sendData(sock_cmd, ftpbuf, strlen(ftpbuf));
	if(_resp_check() != 200)
		return(num);

	rwmode = 0;
	if(pasv_mod() == false)
		return(num);

	sprintf(ftpbuf, "LIST %s\r\n", wild);
	sendData(sock_cmd, ftpbuf, strlen(ftpbuf));
	if(_resp_check() != 150)
		return(num);

//swiWaitForVBlank();

	bc = 0x0A;
	s = fin = 0;
	while(1) {
		len = recvData(sock_data, ftpbuf, FTPBUFSIZE, 0);
		if(len <= 0)	break;
		p = 0;
		while(p < len) {
			if(bc == 0) {
				while(p < len) {
					if(ftpbuf[p] == 0x0A) {
						file[s] = 0;
						bc = 1;
						if(_set_fs(num, file))
							num++;
						break;
					}
					file[s] = ftpbuf[p];
					s++;
					p++;
				}
			}
			if(num >= 200) {
				fin = 1;
				break;
			}

			if(bc == 0x0A && ftpbuf[p] == '-') {
				s = 0;
				bc = 0;
			}
			if(p == len)	p--;
			if(bc != 0)	bc = ftpbuf[p];
			p++;
		}
		if(fin)	break;
	}

	shutdown(sock_data, SHUT_WR);
	closesocket(sock_data);

//	_resp_check();
	recvData(sock_cmd, ftpbuf, FTPBUFSIZE, 0);

	return(num);
}


int FTP_FileSize(char *name)
{
	int	siz = 0;
	int	len, p;


	recvData(sock_cmd, ftpbuf, FTPBUFSIZE, 0);

	sprintf(ftpbuf, "TYPE I\r\n");
	sendData(sock_cmd, ftpbuf, strlen(ftpbuf));
	if(_resp_check() != 200)
		return(-1);

	sprintf(ftpbuf, "SIZE %s\r\n", name);
	sendData(sock_cmd, ftpbuf, strlen(ftpbuf));
	if(_resp_check() != 213)
		return(-1);

	siz = p = 0;
	len = strlen(resdata);
	while(p < len) {
		if((resdata[p] < 0x30) || (resdata[p] > 0x39))
			break;
		siz = siz * 10 + resdata[p] - 0x30;
		p++;
	}

	return(siz);
}


bool FTP_FileTM(char *name, char *tm)
{
	int	i;


	recvData(sock_cmd, ftpbuf, FTPBUFSIZE, 0);

	sprintf(ftpbuf, "MDTM %s\r\n", name);
	sendData(sock_cmd, ftpbuf, strlen(ftpbuf));
	if(_resp_check() != 213)
		return false;

	for(i = 0; i < 14; i++) {
		tm[i] = resdata[i];
	}
	tm[i] = 0;

	return true;
}


bool FTP_Abort()
{

	recvData(sock_cmd, ftpbuf, FTPBUFSIZE, 0);

	sprintf(ftpbuf, "ABOR\r\n");
	sendData(sock_cmd, ftpbuf, strlen(ftpbuf));
	if(_resp_check() != 426)
		return false;

	return true;
}



bool FTP_FileOpen(int mode, char *name)
{


	recvData(sock_cmd, ftpbuf, FTPBUFSIZE, 0);

	sprintf(ftpbuf, "TYPE I\r\n");
	sendData(sock_cmd, ftpbuf, strlen(ftpbuf));
	if(_resp_check() != 200)
		return false;

	rwmode = mode;

	if(pasv_mod() == false)
		return false;

	if(rwmode == 0) {
		sprintf(ftpbuf, "RETR %s\r\n", name);
	} else {
//		sendrem = 0;
		sprintf(ftpbuf, "STOR %s\r\n", name);
	}
	sendData(sock_cmd, ftpbuf, strlen(ftpbuf));

	if(_resp_check() != 150)
		return false;

	return true;
}

bool FTP_FileClose()
{
	vu32	vi;


	if(rwmode == 1) {
//		FTP_FileWrite(senddata, 0);

		for(vi = 0; vi < 40; vi++)	// 500ms
			swiWaitForVBlank();
		shutdown(sock_data, SHUT_RD);
		for(vi = 0; vi < 40; vi++)	// 500ms
			swiWaitForVBlank();

//		while(recvData(sock_data, ftpbuf, 10, 0) > 0);
	} else {
		shutdown(sock_data, SHUT_WR);
	}

	closesocket(sock_data);

//	_resp_check();
	recvData(sock_cmd, ftpbuf, FTPBUFSIZE, 0);

	rwmode = 0;

	return true;
}

int  FTP_FileRead(char *buf, int len)
{
	int	ln, rem;
	u32	p;
	vu32	vi;

	p = 0;
	rem = len;
	ln = recv(sock_data, buf, len, 0);
	if(ln < rem) {
		while(1) {
			if(ln > 0) {
				rem -= ln;
				p += ln;
			}
			if(rem <= 0)	break;

			for(vi = 0; vi < (u32)rem * 200; vi++);	//====== dealy 1byte 0.025ms 375loop
//				swiWaitForVBlank();
			ln = recv(sock_data, buf + p, rem, 0);
		}
	}
	return(len);


//	return recvData(sock_data, buf, len, 0);
}


int  FTP_FileWrite(char *buf, int len)
{
//	int	ln;


	sendData(sock_data, buf, len);
	return(len);


/**********
	if(sendrem != 0) {
		sendData(sock_data, senddata, sendrem);
		sendrem = 0;
	}
	if(len == 0)	return(0);

	ln = send(sock_data,  buf, len, 0);
	if(ln < 0)	ln = 0;
	if(ln == len)	return(len);

	sendrem = len - ln;
	memcpy(senddata, buf + ln, sendrem);

	return(ln);
*****/
}

