#include <nds.h>
#include "wifi.h"

#include <stdlib.h>
#include <stdio.h>

static bool wifiConnected = false;

/************
int wifiConnect(char *host, unsigned short port)
{
	int sock = 0;
	struct hostent	*tcp_he;
	struct sockaddr_in tcp_sain;
	
	tcp_he = gethostbyname(host);
	
	sock = socket(AF_INET,SOCK_STREAM,0);
	tcp_sain.sin_addr.s_addr = *((unsigned long *)(tcp_he->h_addr_list[0]));
	tcp_sain.sin_family = AF_INET;
	tcp_sain.sin_port = htons(port);
	
	setNonBlocking(sock);
	connect(sock, (struct sockaddr *)&tcp_sain, sizeof(tcp_sain));
	
	return sock;
}
****************/


void setBlocking(int sock)
{
	int i = 0;

	ioctl(sock, FIONBIO, &i);	 // set blocking
}

void setNonBlocking(int sock)
{
	int i = 1;

	ioctl(sock, FIONBIO, &i);	 // set non-blocking
}

void sendData(int sock, char *data, int len)
{
	int	ln;
	u32	p;
	vu32	vi;

	p = 0;
	ln = send(sock, data, len, 0);
	if(ln < len) {
		while(1) {
			if(ln > 0) {
				len -= ln;
				p += ln;
			}
			if(len <= 0)	break;

			for(vi = 0; vi < (u32)len * 150; vi++);	//====== dealy 1byte 0.025ms 375loop

			ln = send(sock, data + p, len, 0);
		}
	}
}

int recvData(int sock, char *data, int len, int wait)
{
	return recv(sock, data, len, 0);
}

int wifiConnectIP(int mode, u32 ip, unsigned short port)
{
	int sock = 0;
	struct sockaddr_in tcp_sain;
	
	sock = socket(AF_INET,SOCK_STREAM,0);
	tcp_sain.sin_addr.s_addr = ip;
	tcp_sain.sin_family = AF_INET;
	tcp_sain.sin_port = htons(port);

	if(mode == 0)
		setNonBlocking(sock);
	else	setBlocking(sock);
	connect(sock, (struct sockaddr *)&tcp_sain, sizeof(tcp_sain));

	return sock;
}

u32 ipToLong(char i1, char i2, char i3, char i4)
{
	u32 l;

	l = i1 | (i2 << 8) | (i3 << 16) | (i4 << 24);

	return l;
}

void disconnectWifi()
{
	if(!wifiConnected)
		return;

	wifiConnected = false;

	Wifi_DisconnectAP();
	Wifi_DisableWifi();
}

bool connectWifi()
{
	if(wifiConnected)
		return true;

	return Wifi_InitDefault(WFC_CONNECT);
}

bool isConnected()
{
	return wifiConnected;
}
