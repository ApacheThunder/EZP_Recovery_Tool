#ifdef __cplusplus
extern "C" {
#endif

void LinkReset_ARM9();

#ifdef __cplusplus
}
#endif


/*
  --------------------------
  EDIY Studio
  http://www.gbalink.net
  http://www.ds-link.net
  --------------------------
*/
