
struct	ini_file {
	u8	sv_ip[4];
	u16	port;
	char	dir[64];
	char	user[32];
	char	pass[32];
	u32	save;
	u32	trim;
};

extern	struct	ini_file	ini;

struct	FTP_File {
		char	filename[256];
		u32	filesize;
};

extern	struct	FTP_File	fs[];



#ifdef __cplusplus
extern "C" {
#endif

extern	void	FTP_ini();
extern	bool	FTP_Login();
extern	bool	FTP_Logoff();
extern	int	FTP_FileList(char *wild);
extern	int	FTP_FileSize(char *name);
extern	bool	FTP_FileTM(char *name, char *tm);
extern	bool	FTP_Abort();

extern	bool	FTP_FileOpen(int mode, char *name);
extern	bool	FTP_FileClose();
extern	int	FTP_FileRead(char *buf, int len);
extern	int	FTP_FileWrite(char *buf, int len);

extern	bool	FTP_FileGet(char *name);
extern	bool	FTP_FilePut(char *name);

#ifdef __cplusplus
}
#endif
