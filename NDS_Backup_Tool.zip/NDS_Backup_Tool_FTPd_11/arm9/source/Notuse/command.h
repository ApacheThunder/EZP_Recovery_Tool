
#ifdef __cplusplus
extern "C" {
#endif

int	SaveBK_upd(char *name);
void	SaveBK_new(char *name);
int	Save_Rest(char *name);
int	Save_Init(void);
int	RomBK_upd(char *name);
void	RomBK_new(char *name);

#ifdef __cplusplus
}
#endif
