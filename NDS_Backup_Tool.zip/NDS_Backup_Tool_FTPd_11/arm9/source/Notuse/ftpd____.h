# ifndef PSP_FTPD_H
# define PSP_FTPD_H

  extern int ftpdLoop(const char* szMyIPAddr);

# endif
