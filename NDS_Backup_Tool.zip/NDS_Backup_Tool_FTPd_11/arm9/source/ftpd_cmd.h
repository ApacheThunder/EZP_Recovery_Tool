#ifndef _FTPD_CMD_H
#define _FTPD_CMD_H


#define MAX_USER_LENGTH 50
#define MAX_PASS_LENGTH 50

#define MAX_PATH_LENGTH                 512
#define TRANSFER_MS_BUFFER_SIZE   (256*1024)
#define TRANSFER_RECV_BUFFER_SIZE      1024
#define TRANSFER_SEND_BUFFER_SIZE      4096
#define MAX_COMMAND_LENGTH             1024


typedef struct ftpConnection {
	int sockCommand;
	int sockPASV;
	int sockData;
	int lay;
//	char root[MAX_PATH_LENGTH];
	char curDir[MAX_PATH_LENGTH];
	int userLoggedIn;
	int usePassiveMode;
	char user[MAX_USER_LENGTH];
	char pass[MAX_PASS_LENGTH];
	unsigned char port_addr[4];
	unsigned short port_port;
	char transfertType;
	char serverIp[32];
	char clientIp[32];

//	char renameFromFileName[MAX_PATH_LENGTH];
//	char renameFrom;
  
	char sockCommandBuffer[MAX_COMMAND_LENGTH];
	char sockDataBuffer[MAX_COMMAND_LENGTH];

} ftpConnection;


extern void sendResponseLn(ftpConnection *con, char* s);

extern int ftpServerHello(ftpConnection *con);
extern int ftpDispatch(ftpConnection *con, char* command);
extern int ftpRestrictedCommand(ftpConnection *con, char* command) ;

# endif
