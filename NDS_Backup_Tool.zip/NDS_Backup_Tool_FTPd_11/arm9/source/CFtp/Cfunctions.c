// DSWifi Test Project - copyright Stephen Stair 2005
// Based on template project in ndslib by wntrmute
/****************************************************************************** 
DSWifi Lib and test materials are licenced under the MIT open source licence:
Copyright (c) 2005 Stephen Stair

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
******************************************************************************/

#include "nds.h"
#include <nds/arm9/console.h> //basic print funcionality
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/fcntl.h>

#include <dswifi9.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include <fat.h>

#include "Cfunctions.h" 

#include "ziplib.h"
#include "zl_types.h"
#include "gui_guidef.h"


int psych_mode;

unsigned int Picks =0;
unsigned long InternalPicks=0;

touchPosition touchXY;


void Timer_50ms(void) {
	InternalPicks++;

	if (Picks != 0 ) Picks --;

	Wifi_Timer(WIFI_TIMER_MS);
}



char buffer[256];
void sgIP_dbgprint(char * txt, ...) {

	va_list args;
	va_start(args,txt);
	vsprintf(buffer,txt,args);
	printtop(buffer);		
}

void htmlprint(char * txt, ...) {

	va_list args;
	va_start(args,txt);
	vsprintf(buffer,txt,args);
	printtop(buffer);	
}



void dbgprintserver(char * txt, ...) {

	va_list args;
	va_start(args,txt);
	vsprintf(buffer,txt,args);
	printtop(buffer);		
}
void dbgprintclient_R(char * txt, ...) {

	va_list args;
	va_start(args,txt);
	vsprintf(buffer,txt,args);
	printtop(buffer);		
}
// erreor 
void dbgprintclient_E(char * txt, ...) {

	va_list args;
	va_start(args,txt);
	vsprintf(buffer,txt,args);
	printtopcolor(buffer, 11 );		
}
void dbgprintclient_S(char * txt, ...) {

	va_list args;
	va_start(args,txt);
	vsprintf(buffer,txt,args);
	printtopcolor(buffer, 7);		
}
void sgIP_dbgprint2(char * txt, ...) {

	va_list args;
	va_start(args,txt);
	vsprintf(buffer,txt,args);
	printtop(buffer);		
}


void waitpersecond ( unsigned int nbr )
{


	Picks = nbr * 20 ;
	while (Picks)  clock(); //sgIP_dbgprint("-%d-",Picks);
}

void waitpermillisecond ( unsigned int nbr )
{


	Picks = nbr / 50  ;
	while (Picks)  clock(); //sgIP_dbgprint("-%d-",Picks);

}

unsigned int TCPI_state_progress =0;
unsigned int R_Frame_progress =0;
unsigned int T_Frame_progress =0;


extern void btm_drawprogressrect(int x1,int y1, int x2, int y2, int x);
extern void printbtmTile(int x, int y, unsigned int tile);

void TCPI_state(char * state)
{
	printbtmatcolor(14, 3, 11, "               ");
	printbtmatcolor(14, 3, 11,  state);
/*
	if (TCPI_state_progress >= 10) TCPI_state_progress =0 ; else TCPI_state_progress++;
	printbtmat (26, 4, progress[TCPI_state_progress]);
*/

	int x=30;
   
	printbtmat (x, 1, " ");
	if (TCPI_state_progress >= 4) TCPI_state_progress =0 ; else TCPI_state_progress++;
	printbtmTile (x, 1, TCPI_state_progress+C_TCP_WAIT);

	
	x=29;
   
	printbtmat (x, 1, "S");
	if (TCPI_state_progress >= 4) TCPI_state_progress =0 ; else TCPI_state_progress++;
	printbtmTile (x, 1, TCPI_state_progress+C_APPLE);
	
}

void R_Frame(void)
{
   int x=28;
   
	printbtmat (x, 1, "R");
	if (R_Frame_progress >= 4) R_Frame_progress =0 ; else R_Frame_progress++;
	printbtmTile (x, 1, R_Frame_progress+C_APPLE);
}

void T_Frame(void)
{
   int x=27;
   
	printbtmat (x, 1, "T");
	if (T_Frame_progress >= 4) T_Frame_progress =0 ; else T_Frame_progress++;
	printbtmTile (x, 1, T_Frame_progress+C_APPLE);

}



void P_Frame(int progress)
{
	char buf[10];
	
	if (progress==0) 
	{
		btm_drawprogressrect(2,9, 29, 15, -1);
	}
	else 
	{
		btm_drawprogressrect(2,9, 29, 15, (((29-2)*progress)/100)+2);
	   sprintf(buf, "%3d", progress);
		printbtmat (14, 12, buf);
	}
}

void P_Frame1(int progress)
{
	char buf[10];
	if (progress==0) 
	{
		printbtmat (17,7,"            ");
	}
	else 
	{
		printbtmat (17, 7, "Progr..");
		sprintf(buf, "%3d", progress);
		printbtmat (26, 7, buf);
	}
}

int
memicmp(const void *s1, const void *s2, size_t n)
{
	if (n != 0)
	{
		const unsigned char *p1 = s1, *p2 = s2;

		do {
			if (*p1 != *p2)
			{
				int c = toupper((unsigned char)*p1) - toupper((unsigned char)*p2);
				if (c)
					return c;
			}
			p1++; p2++;
		} while (--n != 0);
	}
	return 0;
}


	char BUFF[500];
void Unzip(const char *zippedFile)
{
	Archive *ar;

	int t,file;
	int aFile; 
	int len;
	int cr,err;
	FILE *f;

	// sgIP_dbgprint("Unziper ,%s,", zippedFile);

	cr = 0; 	
	len = strlen(zippedFile);
	if (len >=5) { 
		if ((zippedFile[len-4] == '.' && zippedFile[len-3] == 'z' && zippedFile[len-2] == 'i' && zippedFile[len-1] == 'p') ||
			(zippedFile[len-4] == '.' && zippedFile[len-3] == 'Z' && zippedFile[len-2] == 'I' && zippedFile[len-1] == 'P'))
			cr=1; 
	}

	if (cr==0) return ; 


	ar = ziplib_open(zippedFile,ziplib_OPEN_R) ;

	for (file=0; file<ar->m_uEntriesNumber;file++)
	{

		if (ziplib_open_file(ar,file,0) == -1) {
			sgIP_dbgprint("ziplib_open_file problem ");
			break;
		}

		len = strlen(ar->opened->m_Name); 

		sgIP_dbgprint("Unzip %s", ar->opened->m_Name);

		if (ar->opened->m_Name[len-1] == '/') { // a repertory 
			sgIP_dbgprint("create dir %s",ar->opened->m_Name);
			mkdir(ar->opened->m_Name, 0777 ); 
			aFile = 0;
		} 
		else { // a file 
			char string2[100];
			char *string;
			char *pdest ;
			char *str ="/"; 
			char tmp[80];

			strncpy(string2, ar->opened->m_Name, 100);
			string = string2;

			do {
		     int  result;
		     pdest = strstr( string, str );
		     result = (int)(pdest - string );

			 if ( pdest != NULL ){ 
			  *(string+result) = 0; 
			  //sgIP_dbgprint( "%s found at position %d\n", string, result );
			  sgIP_dbgprint("create dir %s",string);
			  strncpy(tmp+1, string, 80);
			  tmp[0]='/';
			  mkdir(tmp, 0777 ); 

			  string = string + result + strlen(str);
			 }
			 else break;
			} while (pdest != NULL);

			f=fopen(ar->opened->m_Name,"wb");
			aFile = 1;
		}
		err=0; 
		if (aFile) {
		do {
			t = ziplib_read_file(ar,BUFF,500) ;
			if (t==-1) {
				sgIP_dbgprint("Unzip Cancelled");

				if (aFile) {
					fclose(f); 
					remove(ar->opened->m_Name); 
				}
				else { // a dir
					remove(ar->opened->m_Name);
				}
				err=1; 
				break;
			} 
			else {
				if (aFile) {
					fwrite(BUFF, 1, t, f);  
				}
			}
		} while (t!=0);
		}

		if (ziplib_close_file(ar)== -1) sgIP_dbgprint("ziplib_close_file problem ");

		if (err==0) {
			//sgIP_dbgprint("Unzip Completed");
			if (aFile) fclose(f);
			remove(zippedFile);
		}
	}
}



