

void ScrollUpTop(void);
void ClsTopAlt(int alt);
void ScrollUpTopAlt(int alt);
void PrintCharTopAlt(int alt, int ch);
void SwitchTopDisplay(int alt);
void printtopalt(int alt, int x, int y, const char * str) ;
void printbtmnat(int x, int y, const char * str, int n) ;
void gen_pipe_dream(void);
void btm_drawch_pipedream(int x_, int y_, int c_) ;
void btm_drawch(int x_, int y_, int c_) ;
void btm_drawrect1(int x1,int y1, int x2, int y2) ;
void btm_drawrect2(int x1,int y1, int x2, int y2) ;
void btm_drawbutton(int x1,int y1, int x2, int y2, int s, const char * btntxt) ;
void btm_pddrawrect1(int x1,int y1, int x2, int y2);
void btm_pddrawrect2(int x1,int y1, int x2, int y2);
void btm_pddrawbutton(int x1,int y1, int x2, int y2, int s, const char * btntxt);
void dbgprintbtm(char * txt, ...);
void dbgprintbtmat(int x, int y, char * txt, ...);
void printbtm(const char * str);
void ScrollUpBtm(void);
void ClsBtm(void);


#ifdef __cplusplus
extern "C" void printbtmat(int x, int y, const char * str) ;
extern "C"  void Timer_50ms(void);
extern "C"  void waitpersecond ( unsigned int nbr );
extern "C"  void Unzip(char *zippedFile);
extern "C" void printtop(const char * str);
extern "C" void printtopcolor(const char * str, u16 color );
#endif 

extern int psych_mode;

#define		VRAM1		((u16 *) 0x06000000)
#define		VRAM2		((u16 *) 0x06200000)
#define		VCOUNT		(*((u16 volatile *) 0x04000006))
#define PAL_BG1	((volatile u16 *)0x05000000)
#define PAL_BG2	((volatile u16 *)0x05000400)
#define RGB(r,g,b) ((r) | ((g)<<5) | ((b)<<10))
#define  WIFI_TIMER_MS  50
extern touchPosition touchXY;

