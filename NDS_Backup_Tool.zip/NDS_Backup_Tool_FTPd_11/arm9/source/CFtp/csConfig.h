

extern bool cfgWriteIni(CsString *FilePath, CsString *Section, CsString *Entries, CsString *Value);
extern bool cfgReadIni(CsString *FilePath, CsString *Section, CsString *Entries, CsString * Value);


class blocConfig 
{ 
private :
CsString  sFilePath; 
CsString  dFilePath; 
CsString  dSection ;
FILE     *dfile; 


public :

 bool cfgOpen(CsString *FilePath, CsString *Section) ;
 bool cfgWriteEntries( CsString *Entries,  CsString *Value) ;
 bool cfgClose(void);

}; // end of class 
