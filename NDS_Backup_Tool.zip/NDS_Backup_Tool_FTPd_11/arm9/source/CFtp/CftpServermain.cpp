/*
 * CFtpServer :: a FTP Server Class Library
 *
 * Mail :: thebrowser@gmail.com

  Copyright (C) 2007 Julien Poumailloux

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
	 claim that you wrote the original software. If you use this software
	 in a product, an acknowledgment in the product documentation would be
	 appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
	 misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.
  4. If you like this software, a fee would be appreciated, particularly if
	 you use this software in a commercial product, but is not required.

GCC Compile line:
g++ ./CFtpServer/CFtpServer.cpp ./Example/main.cpp -o FtpServer -Wall -lpthread -D_REENTRANT
Under SunOS and mayber some other OS, you may need to link to '-lsocket', or '-lnsl' too.
Add '-D_FILE_OFFSET_BITS=64' for large file support.

*/
extern "C" void sgIP_dbgprint(char * txt, ...) ;

#include "getopt.h"

#define NDS

#ifdef NDS
#include <fat.h>
#endif

#define CFTPSERVER_CONFIG_H_PATH	"./CFtpServerConfig.h"
#include "CFtpServer.h"
#include "csString.h"
#include "csConfig.h"
#include "Cfunctions.h"

#ifdef CFTPSERVER_ENABLE_EVENTS

extern void waitkey(void );
void OnServerEvent( int Event )
{

	switch( Event )
	{
		case CFtpServer::START_LISTENING:
			dbgprintserver("* Server is listening !\n");
			break;

		case CFtpServer::START_ACCEPTING:
			dbgprintserver("* Server is accepting incoming connexions !\n");
			break;

		case CFtpServer::STOP_LISTENING:
			dbgprintserver("* Server stopped listening !\n");
			break;

		case CFtpServer::STOP_ACCEPTING:
			dbgprintserver("* Server stopped accepting incoming connexions !\n");
			break;
		case CFtpServer::MEM_ERROR:
			dbgprintserver("* Warning, the CFtpServer class could not allocate memory !\n");
			break;
		case CFtpServer::THREAD_ERROR:
			dbgprintserver("* Warning, the CFtpServer class could not create a thread !\n");
			break;
		case CFtpServer::ZLIB_VERSION_ERROR:
			dbgprintserver("* Warning, the Zlib header version differs from the Zlib library version !\n");
			break;
		case CFtpServer::ZLIB_STREAM_ERROR:
			dbgprintserver("* Warning, error during compressing/decompressing data !\n");
			break;
	}
}

void OnUserEvent( int Event, CFtpServer::CUserEntry *pUser, void *pArg )
{
	switch( Event )
	{
		case CFtpServer::NEW_USER:
			dbgprintserver("* A new user has been created:\n"
					"\tLogin: %s\n" "\tPassword: %s\n" "\tStart directory: %s\n",
				pUser->GetLogin(), pUser->GetPassword(), pUser->GetStartDirectory() );
			break;

		case CFtpServer::DELETE_USER:
			dbgprintserver("* \"%s\"user is being deleted: \n", pUser->GetLogin() );
			break;
	}
}

char *
inet_ntoa(struct in_addr ina)
{
	static char buf[4*sizeof "123"];
	unsigned char *ucp = (unsigned char *)&ina;

	sprintf(buf, "%d.%d.%d.%d",
		ucp[0] & 0xff,
		ucp[1] & 0xff,
		ucp[2] & 0xff,
		ucp[3] & 0xff);
	return buf;
}

#define CLEAR_LINE "                                "

void OnClientEvent( int Event, CFtpServer::CClientEntry *pClient, void *pArg )
{
	switch( Event )
	{
		case CFtpServer::NEW_CLIENT:
			dbgprintbtmat(0, 0, "Server at: %s"  , inet_ntoa( *pClient->GetServerIP() ));
			dbgprintbtmat(0, 1, "Connected with: %s"  , inet_ntoa( *pClient->GetIP() ));

			dbgprintclient_R( "A new client has been created:\n");
			break;

		case CFtpServer::DELETE_CLIENT:
			dbgprintbtmat(0, 1, "Not connected ..              ");
			dbgprintclient_R( "A client is being deleted.\n" );
			break;

		case CFtpServer::CLIENT_AUTH:
			dbgprintbtmat(0, 2, "Client as: %s"  , pClient->GetUser()->GetLogin());
			dbgprintclient_R( "A client has logged-in.\n");
			break;

		case CFtpServer::CLIENT_DISCONNECT:
			dbgprintbtmat(0, 1, "Not connected ..              ");
			dbgprintclient_R( "A client has disconnected.\n" );
			break;

		case CFtpServer::CLIENT_UPLOAD:
			dbgprintclient_R( "A client is uploading a file: \"%s\"\n",
				(char*)pArg );
			break;

		case CFtpServer::CLIENT_DOWNLOAD:
			dbgprintclient_R( "A client is downloading a file: \"%s\"\n",
				(char*)pArg );
			break;

		case CFtpServer::CLIENT_LIST:
			dbgprintclient_R( "A client is listing a directory: \"%s\"\n",
				(char*)pArg );
			break;

		case CFtpServer::CLIENT_CHANGE_DIR:
			dbgprintclient_R( "A client has changed its working directory:\n"
				"\tFull path: \"%s\"\n\tWorking directory: \"%s\"\n",
				(char*)pArg, pClient->GetWorkingDirectory() );
			break;

		case CFtpServer::RECVD_CMD_LINE:
			dbgprintclient_R( "Cmd received: %s\n",(char*) pArg );
			break;
		
		case CFtpServer::SEND_REPLY:
			dbgprintclient_S( "Reply sent: %s\n",(char*) pArg );
			break;

		case CFtpServer::TOO_MANY_PASS_TRIES:
			dbgprintclient_E( "Too many pass tries for (%s)\n",
				inet_ntoa( *pClient->GetIP() ) );
			break;

		case CFtpServer::NO_TRANSFER_TIMEOUT:
			dbgprintclient_E( "NO_LOGIN_TIMEOUT\n");
			break;
		case CFtpServer::CLIENT_SOCK_ERROR:
			dbgprintclient_E( "CLIENT_SOCK_ERROR %d \n");
				break;
		case CFtpServer::CLIENT_SOFTWARE:
			dbgprintclient_R( "CLIENT_SOFTWARE\n");
			break;
	}
}

#endif // #ifdef CFTPSERVER_ENABLE_EVENTS

void Usage() {
	sgIP_dbgprint( "Usage:\n"
			" Needed:\n"
			"  -u [login]:[password]   Specify the user login and password.\n"
			"  -d [directory]   Specify the user start directory.\n"
			"\tNote: the password is optional.\n"
			" Optional:\n"
			"  -p [port]   Specify the TCP/IP port the FTP server will listen on.\n"
			"  -r   Give the user the permission to Read files.\n"
			"  -w   Give the user the permission to Write files.\n"
			"\tNote: By default, the user has the permission to list files.\n"
			"  -z   Enable compression for data transfers. (not suported) \n"
			"  -x   Enable server-to-server transfers.\n"
			"Example: program.exe -p 21 -u login:pass -d C:/ -rw\n"
			);
	return;
}



void sleep(int)
{
}

CFtpServer FtpServer;


char UserLogin[60];
char UserPass[60];
char UserStartDirectory [60];
extern bool restart_wifi(void);
extern int master_stop;
extern void launchServer(void )
{
	FtpServer.Create();
	dbgprintserver( "CFtpServer \n\n" );


	int iPort = 21;
	char *pszUserLogin = NULL,
		*pszUserPass = NULL,
		*pszUserStartDirectory = NULL;


	unsigned long ulLocalInterface = INADDR_ANY;
	unsigned char ucUserPriv = CFtpServer::LIST;

	// Default parameters
	FtpServer.SetMaxPasswordTries( 3 );
	FtpServer.SetNoLoginTimeout( 45 ); // seconds
	FtpServer.SetNoTransferTimeout( 90 ); // seconds
	FtpServer.SetDataPortRange( 100, 900 ); // data TCP-Port range = [100-999]
	FtpServer.SetServerCallback(OnServerEvent);
	FtpServer.SetUserCallback(OnUserEvent);
	FtpServer.SetClientCallback(OnClientEvent);
	iPort = 21;
	pszUserLogin = "alain";
	pszUserPass = "alain";
	pszUserStartDirectory = strdup( "/" );
	ucUserPriv |= CFtpServer::READFILE;
	FtpServer.EnableModeZ( true );
	FtpServer.EnableFXP( true );
	ucUserPriv |= CFtpServer::WRITEFILE | CFtpServer::DELETEFILE |
		CFtpServer::CREATEDIR | CFtpServer::DELETEDIR;

	// Load ini parameters

	CsString FilePath("CFtpServer.ini");
	CsString Section ("server_prm");
	CsString Entries ("MaxPasswordTries");
	CsString Value ("0");
	CsString Value2 ("0");

	Entries="MaxPasswordTries";
	if (cfgReadIni(&FilePath, &Section, &Entries, &Value)){
		if (Value.GetLength()>0) FtpServer.SetMaxPasswordTries(atoi(Value));
	}
	Entries="NoLoginTimeout";
	if (cfgReadIni(&FilePath, &Section, &Entries, &Value)){
		if (Value.GetLength()>0) FtpServer.SetNoLoginTimeout(atoi(Value));
	}
	Entries="SetNoTransferTimeout";
	if (cfgReadIni(&FilePath, &Section, &Entries, &Value)){
		if (Value.GetLength()>0) FtpServer.SetNoTransferTimeout(atoi(Value));
	}
	Entries="SetDataPortRangeMin";
	if (cfgReadIni(&FilePath, &Section, &Entries, &Value)){
		if (Value.GetLength()>0) { 
			Entries="SetDataPortRangeMax";
			if (cfgReadIni(&FilePath, &Section, &Entries, &Value2)){
				if (Value2.GetLength()>0) FtpServer.SetDataPortRange(atoi(Value), atoi(Value2));
			}
		}
	}
	Entries="iport";
	if (cfgReadIni(&FilePath, &Section, &Entries, &Value)){
		if (Value.GetLength()>0) iPort=(atoi(Value));
	}
	Entries="UserLogin";
	if (cfgReadIni(&FilePath, &Section, &Entries, &Value)){
		if (Value.GetLength()>0) {
		strcpy(UserLogin,Value); 
		pszUserLogin=UserLogin;
		}
	}
	Entries="UserPass";
	if (cfgReadIni(&FilePath, &Section, &Entries, &Value)){
		if (Value.GetLength()>0) {
		strcpy(UserPass,Value); 
		pszUserPass=UserPass;
		}
	}
	Entries="UserStartDirectory";
	if (cfgReadIni(&FilePath, &Section, &Entries, &Value)){
		if (Value.GetLength()>0) {
		strcpy(UserStartDirectory,Value); 
		pszUserStartDirectory=strdup(UserStartDirectory);
		}
	}
	Entries="UserPriv";
	if (cfgReadIni(&FilePath, &Section, &Entries, &Value)){
		if (Value.GetLength()>0) ucUserPriv=(atoi(Value));
	}
	Entries="EnableModeZ";
	if (cfgReadIni(&FilePath, &Section, &Entries, &Value)){
		if (Value.GetLength()>0)FtpServer.EnableModeZ(atoi(Value));
	}
	Entries="EnableFXP";
	if (cfgReadIni(&FilePath, &Section, &Entries, &Value)){
		if (Value.GetLength()>0)FtpServer.EnableFXP(atoi(Value));
	}

	
	if( !pszUserLogin ) {
		dbgprintserver("/!\\Error: User Login is missing.\n\n" );
		Usage();
		return ;
	}
	if( !pszUserStartDirectory ) {
		dbgprintserver("/!\\Error: User Start directory is missing.\n\n" );
		Usage();
		return ;
	}

	CFtpServer::CUserEntry *pUser = FtpServer.AddUser( pszUserLogin, pszUserPass, pszUserStartDirectory );

	if( pUser ) {
		// dbgprintserver("user Ok ...");
		pUser->SetMaxNumberOfClient( 0 ); // Unlimited
		pUser->SetPrivileges( ucUserPriv );

		// If you only want to listen on the TCP Loopback interface,
		// replace 'INNADDR_ANY' by 'inet_addr("127.0.0.1")'.

		master_stop=0;
		while(master_stop==0){
		// dbgprintserver( "-Server is listening ! :)\n" );
		printbtmat(0,0,"Wait Ftp Client ...");
		printbtmat(0,21,"!! Never reset during file SD card writing");
		printbtmat(0,23,"Reset to quit Ftp Server");

		if( FtpServer.StartListening( ulLocalInterface, (unsigned short) iPort ) ) {
			dbgprintserver( "-Server successfuly started ! :)\n" );

			if (master_stop==0) 
				FtpServer.StartAccepting();

			dbgprintserver( "-Unable to accept incoming connections.\n" );
			FtpServer.StopListening();
			waitpersecond(1);
		}
		restart_wifi();
	  }

	} else dbgprintserver( "-Unable to create the User.\n" );

	dbgprintserver( "-Exiting.\n" );

	if( pszUserStartDirectory ) delete [] pszUserStartDirectory;

	FtpServer.Delete();

	return ;
}
