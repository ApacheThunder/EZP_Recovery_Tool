#include <nds.h>
#include <fat.h>

//#include "dswifi/wifi_shared.h"
#include <dswifi9.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

//#include <sys/dir.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ftpd_cmd.h"
#include "ftpd.h"

#include "maindef.h"
#include "CardRead.h"
#include "rom_prc.h"

#include "message.h"

#include "tarosa/tarosa_Graphic.h"
#include "tarosa/tarosa_Shinofont.h"
extern uint16* MainScreen;
extern uint16* SubScreen;
//uint16* MainScreen = VRAM_A;
//uint16* SubScreen = (uint16*)BG_TILE_RAM_SUB(1);

//#define WAIT_CR	REG_EXMEMCNT

//extern u32 Wifi_GetIP();


char	GameTitle[13];
char	Gamecode[5];
char	RomVer;
u32	Devicecapacity;
u32	UsedROMsize;
u32	romID;

int	savetype;
int	nosupport;
u32	savesize;
u8	flashID[3];

int	HGSS_CS;

char	*keytbl;
char	*key2tbl;
char	*key1tbl;
char	*romhead;
char	*romsc1;
char	*romsc2;

char	*info;

char	tbuf[256];


#define NDS_TYPE	 (*(vu8*)0x027FFDF0)
#define KEY_TBL_ADR	(*(vu32*)0x027FFDF4)


int inp_cmd()
{
	u32	ky;

	scanKeys();
	ky = keysUp();
	if(ky & KEY_X)		return(1);
	if(ky & KEY_START)	return(2);

	return(0);
}


u32 inp_key()
{
	u32	ky;

	while(1) {
		swiWaitForVBlank();
		scanKeys();
		ky = keysDown();
		if(ky & KEY_A)	break;
		if(ky & KEY_B)	break;
	}
	while(1) {
		swiWaitForVBlank();
		scanKeys();
		if(keysHeld() != ky)	break;
	}
	return(ky);
}


void turn_off(int cmd)
{
	powerOn(PM_SYSTEM_PWR);
	while(1);
}


void err_cnf(int n1, int n2)
{
	int	len;
	int	x1, x2;
	int	y1, y2;
	int	xi, yi;
	u16	*gback;
	int	gsiz;

	len = strlen(errmsg[n1]);
	if(len < strlen(errmsg[n2]))
		len = strlen(errmsg[n2]);
	if(len < 10)	len = 10;

	x1 = (256 - len * 6) / 2 - 4;
	y1 = 4*12-6;
	x2 = x1 + len * 6 + 9;
	y2 = 8*12+3;

	gsiz = (x2-x1+1) * (y2-y1+1);
	gback = (u16*)malloc(sizeof(u16*) * gsiz);
	for( yi=y1; yi<y2+1; yi++ ){
		for( xi=x1; xi<x2+1; xi++ ){
			gback[(xi-x1)+(yi-y1)*(x2+1-x1)] = Point_SUB( SubScreen, xi, yi );
		}
	}

	DrawBox_SUB( SubScreen, x1, y1, x2, y2, 6, 0);
	DrawBox_SUB( SubScreen, x1+1, y1+1, x2-1, y2-1, 2, 1);
	DrawBox_SUB( SubScreen, x1+2, y1+2, x2-2, y2-2, 6, 0);

	ShinoPrint_SUB(SubScreen, x1 + 6, y1 + 6, (u8 *)errmsg[n1], 0, 0, 0);
	ShinoPrint_SUB(SubScreen, x1 + 6, y1 + 20, (u8 *)errmsg[n2], 0, 0, 0);
	ShinoPrint_SUB(SubScreen, x1 + (len/2)*6 - 18, y1 + 37, (u8*)errmsg[0], 0, 0, 0);


	while(!(inp_key() & KEY_A));

	for( yi=y1; yi<y2+1; yi++ ){
		for( xi=x1; xi<x2+1; xi++ ){
			Pixel_SUB(SubScreen, xi, yi, gback[(xi-x1) + (yi-y1)*(x2+1-x1)] );
		}
	}
	free(gback);

//	turn_off(0);

}


int cnf_inp(int mode, int n1, int n2)
{
	int	len;
	int	x1, x2;
	int	y1, y2;
	int	xi, yi;
	u16	*gback;
	int	gsiz;
	u32	ky;
	char	*msg1;

	if(n1 < 0)
		msg1 = tbuf;
	else	msg1 = cnfmsg[n1];
	len = strlen(msg1);
	if(len < strlen(cnfmsg[n2]))
		len = strlen(cnfmsg[n2]);
	if(len < 20)	len = 20;

	x1 = (256 - len * 6) / 2 - 4;
	y1 = 4*12-6;
	x2 = x1 + len * 6 + 9;
	y2 = 8*12+3;

	gsiz = (x2-x1+1) * (y2-y1+1);
	gback = (u16*)malloc(sizeof(u16*) * gsiz);
	for( yi=y1; yi<y2+1; yi++ ){
		for( xi=x1; xi<x2+1; xi++ ){
			gback[(xi-x1)+(yi-y1)*(x2+1-x1)] = Point_SUB( SubScreen, xi, yi );
		}
	}

	DrawBox_SUB( SubScreen, x1, y1, x2, y2, 6, 0);
	DrawBox_SUB( SubScreen, x1+1, y1+1, x2-1, y2-1, 5, 1);
	DrawBox_SUB( SubScreen, x1+2, y1+2, x2-2, y2-2, 6, 0);

	ShinoPrint_SUB(SubScreen, x1 + 6, y1 + 6, (u8 *)msg1, 0, 0, 0);
	ShinoPrint_SUB(SubScreen, x1 + 6, y1 + 20, (u8 *)cnfmsg[n2], 0, 0, 0);
	ShinoPrint_SUB(SubScreen, x1 + (len/2)*6 - 50, y1 + 37, (u8*)cnfmsg[mode], 0, 0, 0);


	ky = inp_key();

	for( yi=y1; yi<y2+1; yi++ ){
		for( xi=x1; xi<x2+1; xi++ ){
			Pixel_SUB(SubScreen, xi, yi, gback[(xi-x1) + (yi-y1)*(x2+1-x1)] );
		}
	}
	free(gback);
	return(ky);
}


u16	*gbar = NULL;
int	oldper;

void dsp_bar(int mod, int per)
{
	int	x1, x2;
	int	y1, y2;
	int	xi, yi;
	int	gsiz;

	x1 = 49;
	y1 = 142-6;	//70;
	x2 = 205;
	y2 = 187-6;	//115;

	if(per < 0) {
		gsiz = (x2-x1+1) * (y2-y1+1);
		gbar = (u16*)malloc(sizeof(u16*) * gsiz);
		for( yi=y1; yi<y2+1; yi++ ){
			for( xi=x1; xi<x2+1; xi++ ){
				gbar[(xi-x1)+(yi-y1)*(x2+1-x1)] = Point_SUB(SubScreen, xi, yi );
			}
		}

		DrawBox_SUB(SubScreen, x1, y1, x2, y2, 6, 0);
		DrawBox_SUB(SubScreen, x1+1, y1+1, x2-1, y2-1, 5, 1);
		DrawBox_SUB(SubScreen, x1+2, y1+2, x2-2, y2-2, 6, 0);

		if(per != -2)
			DrawBox_SUB(SubScreen, x1 + 28, y1 + 20, x1 + 129, y1 + 40, 0, 0);
		ShinoPrint_SUB(SubScreen, x1 + 26, y1 + 6, (u8 *)barmsg[mod], 0, 0, 0);
		oldper = -1;
		return;
	}

	if(gbar == NULL)	return;

	if(per != oldper) {
		oldper = per;
		if(per > 0)
			DrawBox_SUB(SubScreen, x1 + 29, y1 + 21, x1 + 28 + per, y1 + 39, 2, 1);
		if(per < 100)
			DrawBox_SUB(SubScreen, x1 + 28 + per + 1, y1 + 21, x1 + 128, y1 + 39, 3, 1);
		sprintf(tbuf, "%2d%%", per);
		ShinoPrint_SUB(SubScreen, x1 + 74, y1 + 24, (u8 *)tbuf, 0, 0, 0);
	}

	if(mod == -1) {
		for( yi=y1; yi<y2+1; yi++ ){
			for( xi=x1; xi<x2+1; xi++ ){
				Pixel_SUB(SubScreen, xi, yi, gbar[(xi-x1) + (yi-y1)*(x2+1-x1)] );
			}
		}
		free(gbar);
		gbar = NULL;
	}
	return;
}

/*****
void _dsp_clear()
{
//	DrawBox_SUB(SubScreen, 0, 28, 255, 114, 0, 1);
	DrawBox_SUB(SubScreen, 0, 28, 255, 114, 0, 1);

}
******/


extern	int card_info(void);
extern	void flashIdRead(uint8 *id);


bool set_rom()
{
//	int	len;
	int	i;
	u32	gc;

	HGSS_CS = 0;
	nosupport = 0;

//	sprintf(tbuf, "Ky2 : %02X %02X %02X %02X", key2tbl[0], key2tbl[1], key2tbl[2], key2tbl[3]);
//	ShinoPrint_SUB( SubScreen, 5*6, 12*12, (u8 *)tbuf, 1, 0, 0);
//	sprintf(tbuf, "Ky1 : %02X %02X %02X %02X", key1tbl[0], key1tbl[1], key1tbl[2], key1tbl[3]);
//	ShinoPrint_SUB( SubScreen, 5*6, 13*12, (u8 *)tbuf, 1, 0, 0);

	if(cnf_inp(0, 2, 3) & KEY_B)
		return false;

	romID = Rom_Read(0, (u8*)romhead, (u8*)romsc1);
	while(romID == 0xFFFFFFFF) {
		if(cnf_inp(0, 7, 8) & KEY_B)
			return false;

		romID = Rom_Read(1, (u8*)romhead, (u8*)romsc1);
	}


	for(i = 0; i < 12; i++) {
		if((romhead[i] >= 0x30 && romhead[i] <= 0x39) || (romhead[i] >= 0x41 && romhead[i] <= 0x5A))
			GameTitle[i] = romhead[i];
		else	GameTitle[i] = '_';
	}
	GameTitle[i] = 0;
	for(i = 11; i >=0; i--) {
		if(GameTitle[i] != '_')
			break;
	}
	if(i != 0)	GameTitle[i+1] = 0;


	for(i = 0; i < 4; i++) {
		if((romhead[i+0x0C] >= 0x30 && romhead[i+0x0C] <= 0x39) || (romhead[i+0x0C] >= 0x41 && romhead[i+0x0C] <= 0x5A))
			Gamecode[i] = romhead[i+0x0C];
		else	Gamecode[i] = '_';
	}
	Gamecode[i] = 0;

	RomVer = romhead[0x1E];

	Devicecapacity = (128 << romhead[0x14]) * 1024;
	UsedROMsize = *((u32*)(romhead + 0x80));

	savetype = cardEepromGetType();	// cardmeGetType();
	if(savetype > 0) {
		savesize = cardEepromGetSize();	// cardmeSize(savetype);
		if(savesize == 0)	savetype = 0;
	} else	savesize = 0;

////////////////////////////////////////
gc = *((u32*)(romhead + 0x0C)) & 0x00FFFFFF;
if(savetype != 1 && savetype != 2) {		// Not EEPROM

	if(gc == 0x4B5049) {		// Pokemon Heart Gold FLASH 4M
		savesize = 512 * 1024;
		nosupport = 1;
		savetype = 3;
		HGSS_CS = 1;
	}
	if(gc == 0x475049) {		// Pokemon Soul Silver FLASH 4M
		savesize = 512 * 1024;
		nosupport = 1;
		savetype = 3;
		HGSS_CS = 1;
	}

	if(gc == 0x503643) {		// Rittai Picross FLASH 4M
		savesize = 512 * 1024;
		savetype = 3;
	}
	if(gc == 0x415943) {		// Taiheiyou no Arashi FLASH 4M
		savesize = 512 * 1024;
		savetype = 3;
	}

	if(gc == 0x593241) {		// Kakei Diary FLASH 4M
		savesize = 512 * 1024;
		savetype = 3;
	}
	if(gc == 0x484E41) {		// Motto Eigo Zuke FLASH 4M
		savesize = 512 * 1024;
		savetype = 3;
	}
	if(gc == 0x455A41) {		// ZELDA_DS FLASH 4M
		savesize = 512 * 1024;
		savetype = 3;
	}
	if(gc == 0x414441) {		// Pokemon_D FLASH 4M
		savesize = 512 * 1024;
		savetype = 3;
	}
	if(gc == 0x415041) {		// Pokemon_P FLASH 4M
		savesize = 512 * 1024;
		savetype = 3;
	}
	if(gc == 0x574D49) {		// Seikatsu Rhythm FLASH 4M
		savesize = 512 * 1024;
		savetype = 3;
	}
	if(gc == 0x4D5641) {		// Bimoji Training FLASH 4M
		savesize = 512 * 1024;
		savetype = 3;
	}
	if(gc == 0x413341) {		//  Umania 2007 FLASH 4M
		savesize = 512 * 1024;
		savetype = 3;
	}
	if(gc == 0x474443) {		//  Disgaea FLASH 4M
		savesize = 512 * 1024;
		savetype = 3;
	}
	if(gc == 0x555043) {		//  Pokemon Platinum FLASH 4M
		savesize = 512 * 1024;
		savetype = 3;
	}

	if(gc == 0x4E4259) {		// Bungaku Zenshuu FLASH 8M
		savesize = 1024 * 1024;
		savetype = 3;
	}
	if(gc == 0x4C5A41) {		// Girls Mode FLASH 8M
		savesize = 1024 * 1024;
		savetype = 3;
	}

	if(gc == 0x425841) {		// Band Brothers DX FLASH 64M
		savesize = 8192 * 1024;
		savetype = 3;
	}

	if(gc == 0x524F55) {		// Maide in Ore FLASH 128M
//		savesize = 16384 * 1024;
		savesize = 0;
//		nosupport = 1;
		savetype = 0;
	}
}

	if(savetype == 3) {
		flashIdRead(flashID);
	} else {
		flashID[0] = flashID[1] = flashID[2] = 0;
	}
///////////////////////////////////////

	DrawBox_SUB(SubScreen, 6, 32, 249, 76+60, 5, 0);
	DrawBox_SUB(SubScreen, 8, 34, 247, 74+60, 5, 0);
	DrawBox_SUB(SubScreen, 9, 4*12, 246, 11*12-1, 0, 1);


	ShinoPrint_SUB( SubScreen, 2*6, 3*12+3, (u8 *)"< ROM Information >", 1, 0, 0);

	sprintf(tbuf, "Game Title : %s %s %02X", GameTitle, Gamecode, RomVer);
	ShinoPrint_SUB( SubScreen, 5*6, 4*12+9, (u8 *)tbuf, 1, 0, 0);

	sprintf(tbuf, "Chip ID : %02X %02X %02X %02X", romID & 0xFF, (romID >> 8) & 0xFF, (romID >> 16) & 0xFF, (romID >> 24) & 0xFF);
	ShinoPrint_SUB( SubScreen, 5*6, 6*12+3, (u8 *)tbuf, 1, 0, 0);

	sprintf(tbuf, "ROM Size(Used) : %6.2fMB(%6.2fMB)", (float)Devicecapacity / (1024*1024), (float)UsedROMsize / (1024*1024));
	ShinoPrint_SUB( SubScreen, 5*6, 7*12+9, (u8 *)tbuf, 1, 0, 0);

	if(savetype == -1)
		sprintf(tbuf, "SAVE Type : 0 (Not provide)");
	if(savetype == 0)
		sprintf(tbuf, "SAVE Type : Unknown");
	if(savetype == 1)
		sprintf(tbuf, "SAVE Type : EEPROM %dK(%dByte)", savesize / (1024/8), savesize);
	if(savetype == 2)
		sprintf(tbuf, "SAVE Type : EEPROM %dK(%dKByte)", savesize / (1024/8), savesize / 1024);
	if(savetype == 3) {
		if(nosupport)
			sprintf(tbuf, "SAVE Type : No Support %dM", savesize / (1024*1024/8));
		else	sprintf(tbuf, "SAVE Type : FLASH %dM(%dKByte)", savesize / (1024*1024/8), savesize / 1024);
	}
	ShinoPrint_SUB( SubScreen, 5*6, 9*12+3, (u8 *)tbuf, 1, 0, 0);

	filecnt = card_info();

	return true;
}




void sts_dsp(int n1)
{
	int	len;
	int	x1, x2;
	int	y1, y2;

	len = 32;

	x1 = (256 - len * 6) / 2 - 4;
	y1 = 5*12-6;
	x2 = x1 + len * 6 + 9;
	y2 = 7*12+3;

	if(n1 < 0) {
		DrawBox_SUB( SubScreen, x1, y1, x2, y2, 0, 1);
		return;
	}

	DrawBox_SUB( SubScreen, x1, y1, x2, y2, 6, 0);
	DrawBox_SUB( SubScreen, x1+1, y1+1, x2-1, y2-1, 5, 1);
	DrawBox_SUB( SubScreen, x1+2, y1+2, x2-2, y2-2, 6, 0);

	len = strlen(stsmsg[n1]);
	ShinoPrint_SUB(SubScreen, 128 - (len/2)*6, y1 + 12, (u8 *)stsmsg[n1], 0, 0, 0);
}

void dsp_main()
{
	struct in_addr ip;

	DrawBox(MainScreen, 2, 2, 253, 83, RGB15(0,0,0), 0);
	DrawBox(MainScreen, 3, 3, 252, 82, RGB15(0,0,31), 1);
	DrawBox(MainScreen, 4, 4, 251, 81, RGB15(31,31,31), 0);

	ip.s_addr = Wifi_GetIP();
	sprintf(tbuf, "FTP Server IP : %s  Port %d", inet_ntoa(ip), ini.port);
	ShinoPrint(MainScreen, 11, 10, (u8 *)tbuf, RGB15(31,31,31), RGB15(31,31,31), 0);

	if(ini.save == 0)
		sprintf(tbuf, "Save File Size : Auto");
	else	sprintf(tbuf, "Save File Size : %dKB", ini.save);
	ShinoPrint(MainScreen, 60, 28, (u8 *)tbuf, RGB15(31,31,31), RGB15(31,31,31), 0);

	sprintf(tbuf, "    User Name : %s", ini.user);
	ShinoPrint(MainScreen, 11, 46, (u8 *)tbuf, RGB15(31,31,31), RGB15(31,31,31), 0);

//	if(ini.trim != 0)
//		sprintf(tbuf, "Rom Backup Type: Trim ");
//	else	sprintf(tbuf, "Rom Backup Type: Not Trim");
//	ShinoPrint(MainScreen, 60, 48, (u8 *)tbuf, RGB15(31,31,31), RGB15(31,31,31), 0);
//	ShinoPrint(MainScreen, 60, 48, (u8 *)tbuf, RGB15(16,16,16), RGB15(31,31,31), 0);

}

static int waitblink = 0;

void dsp_connect(char *ip)
{
	if(ip == NULL) {
		waitblink ^= 1;
		if(waitblink)
			sprintf(tbuf, "       === Waiting connection === ");
		else	sprintf(tbuf, "                                  ");
		ShinoPrint(MainScreen, 11, 64, (u8 *)tbuf, RGB15(30,0,0), RGB15(0,0,31), 1);
		return;
	}

	waitblink = 0;
	sprintf(tbuf, "   Connect IP : %s           ", ip);
	ShinoPrint(MainScreen, 11, 64, (u8 *)tbuf, RGB15(31,31,0), RGB15(0,0,31), 1);
}

static int oldmod = -1;

void dsp_cmd(int mod)
{
	int	p = 1;

	if(oldmod == mod)	return;

	oldmod = mod;
	if(mod == 1)	p = 7;

	ShinoPrint_SUB( SubScreen, 5*6, 13*12+8, (u8 *)t_msg[1], p, 0, 1);

}

extern	void	setLang(void);


//Wifi_MainStruct Wifi_Data_Struct;
//extern Wifi_MainStruct * WifiData;



void mainloop(void)
{
	NDS_TYPE = 0;

	keytbl = (char *)malloc(0x1200);
	KEY_TBL_ADR = (u32)keytbl;
	key2tbl = keytbl + 0x2A;
	key1tbl = keytbl + 0x30;
	romhead = (char *)malloc(0x200);
	romsc1 = (char *)malloc(0x4000);
	romsc2 = (char *)malloc(0x4000);

	info = (char *)malloc(0x400);


	keysSetRepeat(20, 6);		// def. 60, 30 (delay, repeat)

	DrawBox_SUB(SubScreen, 20, 3, 235, 27, 1, 0);
	DrawBox_SUB(SubScreen, 21, 4, 234, 26, 5, 1);
	DrawBox_SUB(SubScreen, 22, 5, 233, 25, 0, 0);
	ShinoPrint_SUB( SubScreen, 9*6, 1*12-2, (u8*)"NDS Backup Tool (FTPd)", 0, 0, 0 );
	ShinoPrint_SUB( SubScreen, 33*6-1, 12, (u8 *)"v0.11", 0, 0, 0 );


	setLangMsg();

	while(NDS_TYPE == 0)
		swiWaitForVBlank();

	if((NDS_TYPE & 0x7F) == 3) {	// DSi Hardware
		err_cnf(11, 12);

		free(info);
		free(key2tbl);
		free(romhead);
		free(romsc1);
		free(romsc2);

		turn_off(0);
	}

	if((NDS_TYPE & 0x80) == 0) {	// AC External Power
		if(cnf_inp(0, 4, 5) & KEY_B) {
			free(info);
			free(key2tbl);
			free(romhead);
			free(romsc1);
			free(romsc2);

			turn_off(0);
		}
	}

	sts_dsp(0);

	fatInitDefault();

//	sts_dsp(1);
//	initWifi();

	sts_dsp(2);
	if(connectWifi() != true) {
		sts_dsp(-1);
		err_cnf(3, 4);

		free(key2tbl);
		free(romhead);
		free(romsc1);
		free(romsc2);
		turn_off(0);
	}

	sts_dsp(3);

	FTPd_ini();
	dsp_main();

	sts_dsp(-1);

	DrawBox_SUB(SubScreen, 6, 149, 249, 190, 5, 0);
	DrawBox_SUB(SubScreen, 8, 151, 247, 188, 5, 0);


/***************
int i;
for(i = 0; i < 3; i++) {
sprintf(tbuf, "%02X %s", WifiData->wfc_enable[i], (u8 *)(WifiData->wfc_ap[i].ssid)+1);
ShinoPrint_SUB( SubScreen, 6, (5+i)*12, (u8 *)tbuf, 1, 0, 0 );
}
inp_key();
***************/

	while(set_rom()) {
		if(ftpd() == 2)	break;		// END
	}

	disconnectWifi();

	free(info);
	free(key2tbl);
	free(romhead);
	free(romsc1);
	free(romsc2);

	turn_off(0);

}


//---------------------------------------------------------------------------------
int main(void) {
//---------------------------------------------------------------------------------

	int	i;

  vramSetMainBanks(VRAM_A_LCD ,  VRAM_B_LCD  , VRAM_C_SUB_BG, VRAM_D_MAIN_BG  );
//	powerON(POWER_ALL);
/////	fifoSendValue32(FIFO_PM, PM_REQ_ON | (POWER_ALL & 0xFFFF));
//	consoleDemoInit();

//	irqInit();
//	irqSet(IRQ_VBLANK, Vblank);
//	irqEnable(IRQ_VBLANK);
//	FIFOInit();

 videoSetMode(MODE_FB0 | DISPLAY_BG2_ACTIVE);
 videoSetModeSub(MODE_0_2D | DISPLAY_BG0_ACTIVE );
 (*(vuint16*)0x04001008) = (BIT(7)) | BG_MAP_BASE(0) | BG_TILE_BASE(1);
// VRAM_C_CR = BG_256_COLOR | BG_MAP_BASE(0) | BG_TILE_BASE(1);
 uint16* map1 = (uint16*)BG_MAP_RAM_SUB(0);
 for(i=0;i<(256*192/8/8);i++)	map1[i]=i;
 lcdMainOnTop();
	ClearBG( MainScreen, RGB15(31,31,31) );
//	ClearBG( MainScreen, RGB15(0,0,0) );

	//�T�u��ʂ̕\��
	BG_PALETTE_SUB[0] = RGB15(31,31,31);		//(��)�T�u��ʂ̃o�b�N�J���[
	BG_PALETTE_SUB[1] = RGB15(0,0,0);			//(��)�T�u��ʂ̃t�H�A�J���[
	BG_PALETTE_SUB[2] = RGB15(30,0,0);			//(��)
	BG_PALETTE_SUB[3] = RGB15(0,30,0);			//(��)
	BG_PALETTE_SUB[4] = RGB15(0,31,31);			//(���F)
	BG_PALETTE_SUB[5] = RGB15(0,0,31);			//(��)
	BG_PALETTE_SUB[6] = RGB15(31,31,0);			//(��)
	BG_PALETTE_SUB[7] = RGB15(24,24,24);			//(�D)

	ClearBG_SUB( SubScreen, 0 );				//�o�b�N�𔒂�


	swiWaitForVBlank();
	sysSetBusOwners(BUS_OWNER_ARM9,BUS_OWNER_ARM9);
	swiWaitForVBlank();


//	iprintf("%s\n%s\n%s\n\n", ROMTITLE, ROMVERSION, ROMDATE);

	mainloop();

	return 0;
}


