//#define cWAIT_1ms 16755

#include <nds.h>
#include <dswifi9.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "sutils.h"
#include "ftpd_cmd.h"
#include "ftpd.h"
#include "rom_prc.h"
#include "CardRead.h"

#include "print_log.h"

extern	int	savetype;
extern	u32	savesize;

extern	char	*romsc2;
extern	char	*info;

extern	void	dsp_bar(int mod, int per);


const char* months[12] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

//extern unsigned long count_100ms;


u16	sendcnt = 0;

int send_data(int sock, char *data, int len)
{
	int	ln;
	int	p;
	int	err;
	vu16	vi;

	p = 0;
	err = 0;

	while(1) {
		if(sendcnt > 50) {
			sendcnt = 0;
//			print_log(1, "Wait");
			for(vi = 0; vi < 150; vi++)
				swiWaitForVBlank();
		}

		ln = send(sock, data + p, len, 0);
		if(ln < 0) {
			err++;
			sendcnt++;
			if(err > 20)	break;
		} else {
			len -= ln;
			p += ln;
			if(len <= 0) {
				if(sendcnt > 0)	sendcnt--;
				break;
			}
		}

		sendcnt++;
		for(vi = 0; vi < 6; vi++)
			swiWaitForVBlank();
	}

	return p;
}


int recv_data(int sock, char *data, int len)
{
	int	ln;
	int	p;
	int	err;
	u16	vi;

	p = 0;
	err = 0;

	while(1) {
		ln = recv(sock, data + p, len, 0);
		if(ln <= 0) {
			err++;
			if(err > 15)	break;
		} else {
			len -= ln;
			p += ln;
			if(len <= 0)	break;
		}
		for(vi = 0; vi < 2; vi++)
			swiWaitForVBlank();
	}

	return p;

}



void sendResponse(ftpConnection *con, char* s) 
{
	strcat(con->sockCommandBuffer, s);
	if(endsWith(con->sockCommandBuffer, "\n")) {
		send_data(con->sockCommand, con->sockCommandBuffer, strlen(con->sockCommandBuffer));
//print_log(0, con->sockCommandBuffer);
		strcpy(con->sockCommandBuffer, "");
	}
}

void sendResponseLn(ftpConnection *con, char* s)
{
	strcat(con->sockCommandBuffer, s);
	strcat(con->sockCommandBuffer, "\r\n");
	send_data(con->sockCommand, con->sockCommandBuffer, strlen(con->sockCommandBuffer));
//print_log(0, con->sockCommandBuffer);
	strcpy(con->sockCommandBuffer, "");
}

void sendData(ftpConnection *con, char* s) 
{
	strcat(con->sockDataBuffer, s);
	if(endsWith(con->sockDataBuffer, "\n")) {
		send_data(con->sockData, con->sockDataBuffer, strlen(con->sockDataBuffer));
//print_log(1, con->sockDataBuffer);
		strcpy(con->sockDataBuffer, "");
	}
}

void sendDataLn(ftpConnection *con, char* s) {
	strcat(con->sockDataBuffer, s);
	strcat(con->sockDataBuffer, "\r\n");
	send_data(con->sockData, con->sockDataBuffer, strlen(con->sockDataBuffer));
//print_log(1, con->sockDataBuffer);
	strcpy(con->sockDataBuffer, "");
}


void _transfertType(ftpConnection *con) {

	char *type = "";

	if(con->transfertType == 'A')
		type = "ASCII";
	if(con->transfertType == 'E')
		type = "EBCDIC";
	if(con->transfertType == 'I')
		type = "BINARY";

	sendResponse(con, "150 Opening ");
	sendResponse(con, type);
	sendResponse(con, " mode data connection for '");
}


unsigned short pasvPort = 59735;

int openDataConnectionPASV(ftpConnection *con) 
{
	con->usePassiveMode = 1;

	int err;

	struct sockaddr_in addrPort;
	memset(&addrPort, 0, sizeof(struct sockaddr_in));

	addrPort.sin_family = AF_INET;
	addrPort.sin_port = htons(pasvPort);
	addrPort.sin_addr.s_addr = 0;

	con->sockPASV = socket(AF_INET, SOCK_STREAM, 0);
	if(con->sockPASV & 0x80000000) return 0;

	err = bind(con->sockPASV, (struct sockaddr *)&addrPort, sizeof(addrPort));
	if(err) return 0;

	err = listen(con->sockPASV, 1);
	if(err) return 0;

	pasvPort++;
	return 1;
}


int openDataConnection(ftpConnection *con) {
	int err;

	if (con->usePassiveMode) {
		struct sockaddr_in addrAccept;
		int cbAddrAccept;

		cbAddrAccept = sizeof(addrAccept);
		con->sockData = accept(con->sockPASV, (struct sockaddr *)&addrAccept, &cbAddrAccept);
		if(con->sockData & 0x80000000) return 0;

		setNonBlocking(con->sockData);
//print_log(2, "PASV DATA ACCEPT");

		return 1;
	}

	struct sockaddr_in addrPort;
	memset(&addrPort, 0, sizeof(struct sockaddr_in));

//	addrPort.sin_reserved = sizeof(struct sockaddr_in);
	addrPort.sin_family = AF_INET;
	addrPort.sin_port = htons(con->port_port);
	addrPort.sin_addr.s_addr = con->port_addr[0] | (con->port_addr[1] << 8) | (con->port_addr[2] << 16) | (con->port_addr[3] << 24);

	con->sockData = socket(AF_INET, SOCK_STREAM, 0);
	if(con->sockData & 0x80000000) return 0;

	err = connect(con->sockData, (struct sockaddr *)&addrPort, sizeof(struct sockaddr_in));
	if(err) return 0;

	setNonBlocking(con->sockData);
//print_log(2, "PORT DATA CONNECT");

	return 1;
}

int closeDataConnection(ftpConnection *con)
{
	int err = 0;
	vu32 vi;

	shutdown(con->sockData, 0);
	if(con->usePassiveMode)
		shutdown(con->sockPASV, 0);

	for(vi = 0; vi < 50; vi++)
		swiWaitForVBlank();

	err |= closesocket(con->sockData);
	if(con->usePassiveMode) {
		err |= closesocket(con->sockPASV);
	}

	if(err) return 0;

	for(vi = 0; vi < 5; vi++)
		swiWaitForVBlank();

	return 1;
}

int ftpServerHello(ftpConnection *con)
{
	sendResponseLn(con, "220 FTP Server Ready");
	return 1;
}

int ftpCommandPWD(ftpConnection *con, char* command) 
{
	if(!ftpRestrictedCommand(con, command))
		return 0;

	sendResponse(con, "257 \"");
	sendResponse(con, con->curDir);
	sendResponseLn(con, "\" is current directory.");

	return 1;
}

int ftpCommandCWD(ftpConnection *con, char* command) 
{
	if(!ftpRestrictedCommand(con, command))
		return 0;

	char* newDir=skipWS(&command[3]);

	trimEndingWS(newDir);

	char parsedDir[MAX_PATH_LENGTH+1];

	char* pParsedDir=parsedDir;
	parsedDir[0]=0;


	char* parser=newDir;
	if((*newDir)=='/') {
		strcpy(con->curDir,"/");
		parser++;
	}

	do {
		if ((*parser)==0 || (*parser)=='/') {
			*pParsedDir=0;
			if(strcmp(parsedDir,".")==0) {

			} else if (strcmp(parsedDir,"..")==0) {
				char* pUp=con->curDir+strlen(con->curDir)-2;
				while ( pUp>=con->curDir && (*pUp)!='/' ) {
					pUp--;
				}
				if ((++pUp)>=con->curDir) {
					*pUp=0;
				}
				if (con->curDir[0]==0) {
					break;
				}
			} else {
				strcat(con->curDir, parsedDir);
				if(!endsWith(con->curDir,"/")) {
					strcat(con->curDir, "/");
				}
			}
			pParsedDir=parsedDir;
		} else {
			(*pParsedDir++)=(*parser);
		}

	} while (*(parser++)!=0);


	if(!endsWith(con->curDir, "/"))
		strcat(con->curDir, "/");

//////// �����Ɛ^�ʖڂɔ��肵��
	con->lay = 0;
	if(strcmp(con->curDir, "/") != 0) {
		strcpy(con->curDir, "/");
		strcat(con->curDir, fs[0].filename);
		strcat(con->curDir, "/");
		con->lay = 1;
	}
////////

	sendResponseLn(con, "250 CWD command successful.");

	return 1;
}

int ftpCommandLIST(ftpConnection *con, char* command) 
{
	if(!ftpRestrictedCommand(con, command))
		return 0;

	if(openDataConnection(con)==0) {
		sendResponseLn(con, "425 impossible to open data connection.");
		return 0;
	}

	_transfertType(con);
	sendResponse(con, con->curDir);
	sendResponseLn(con, "'.");

	int i;
	char sdate[64];


	if(con->lay > 0) {
		sendData(con, "dr-xr-xr-x     0 owner      group               0");
		sprintf(sdate, " %s %02d %02d:%02d .", months[fs[0].month], fs[0].day, fs[0].hh, fs[0].mm);
		sendDataLn(con, sdate);

		sendData(con, "dr-xr-xr-x     0 owner      group               0");
		sprintf(sdate, " %s %02d %02d:%02d ..", months[fs[0].month], fs[0].day, fs[0].hh, fs[0].mm);
		sendDataLn(con, sdate);
	}

	for(i = 0; i < filecnt; i++) {
		if(fs[i].lay == con->lay) {
			if(fs[i].type == 0)
				sendData(con, "dr-xr-xr-x     0 owner      group    ");
			if(fs[i].type == 1 || fs[i].type == 3)
				sendData(con, "-r--r--r--     0 owner      group    ");
			if(fs[i].type == 2)
				sendData(con, "-rw-rw-rw-     0 owner      group    ");
			sprintf(sdate, "%12d %s %02d %02d:%02d ",fs[i].filesize, months[fs[i].month], fs[i].day, fs[i].hh, fs[i].mm);
			sendData(con, sdate);
			sendDataLn(con, fs[i].filename);
		}
	}

	sendResponseLn(con, "226 Transfer complete.");
	closeDataConnection(con);

	return 1;
}

int ftpCommandNLST(ftpConnection *con, char* command) 
{
	if(!ftpRestrictedCommand(con, command))
		return 0;

	if(openDataConnection(con)==0) {
		sendResponseLn(con, "425 impossible to open data connection.");
		return 0;
	}

	_transfertType(con);
	sendResponse(con, con->curDir);
	sendResponseLn(con, "'.");

	int i;

	for(i = 0; i < filecnt; i++) {
		if(fs[i].lay == con->lay) {
			sendDataLn(con, fs[i].filename);
		}
	}

	sendResponseLn(con, "226 Transfer complete.");
	closeDataConnection(con);

	return 1;
}


int ftpCommandRETR(ftpConnection *con, char* command) 
{
	if(!ftpRestrictedCommand(con, command))
		return 0;

	if(openDataConnection(con)==0) {
		sendResponseLn(con, "425 impossible to open data connection.");
		return 0;
	}

	char* fileName=skipWS(&command[5]);
	trimEndingWS(fileName);

	if(strlen(fileName) <= 0) {
		sendResponseLn(con, "500 'RETR': command requires a parameter.");
		closeDataConnection(con);
		return 0;
	}

	char filePath[MAX_PATH_LENGTH];
	char file[MAX_PATH_LENGTH];
	int n, j;

	if (strStartsWith(fileName, "/")) {
		strcpy(filePath, fileName);
	} else {
		strcpy(filePath, con->curDir);
		strcat(filePath, fileName);
	}

	for(n = 0; n < filecnt; n++) {
		if(fs[n].type > 0) {
			strcpy(file, "/");
			for(j = 0; j < filecnt; j++) {
				if((fs[j].type == 0) && (fs[j].lay < fs[n].lay)) {
					strcat(file, fs[j].filename);
					strcat(file, "/");
				}
			}
			strcat(file, fs[n].filename);
			if(strcmp(file, filePath) == 0)	break;
		}
	}

	if(n >= filecnt) {
		sendResponseLn(con, "450 Requested file action not taken.");
		closeDataConnection(con);
		return 0;
	}

	_transfertType(con);
	sprintf(file, "%s' (%d bytes).", fileName, fs[n].filesize);
	sendResponseLn(con, file);


u32	add = 0;
int	sz, len, per;

	dsp_bar(0, -1);
swiWaitForVBlank();
sendcnt = 0;

	sz = fs[n].filesize;
	while(sz) {
		len = 1024;
		if(len > sz)	len = sz;

		if(fs[n].type == 1)	rom_read(add);
		if(fs[n].type == 2)	save_read(add);
		if(fs[n].type == 3)
			memcpy((char *)romsc2, info + add, len);

		per = (int)(((u64)add * 100) / fs[n].filesize);
		dsp_bar(0, per);

		if(send_data(con->sockData, romsc2, len) != len)
			break;
		sz -= len;
		add += len;
	}

	if(sz == 0) {
		dsp_bar(0, 100);
		sendResponseLn(con, "226 Transfer complete.");
	} else	sendResponseLn(con, "426 Connection closed; transfer aborted.");

	closeDataConnection(con);
	dsp_bar(-1, 0);

	return 1;
}

int ftpCommandSTOR(ftpConnection *con, char* command) 
{
	if(!ftpRestrictedCommand(con, command))
		return 0;

	if(openDataConnection(con)==0) {
		sendResponseLn(con, "425 impossible to open data connection.");
		return 0;
	}

	char* fileName=skipWS(&command[5]);
	trimEndingWS(fileName);

	if(strlen(fileName) <= 0) {
		sendResponseLn(con, "500 'STOR': command requires a parameter.");
		closeDataConnection(con);
		return 0;
	}


	char file[MAX_PATH_LENGTH];

	sprintf(file, "%s'.", fileName);

	toUpperCase(fileName);
	if(savetype < 1 || !endsWith(fileName, "SAV")) {
		sendResponseLn(con, "450 Requested file action not taken.");
		closeDataConnection(con);
		return 0;
	}

	_transfertType(con);
	sendResponseLn(con, file);



u32	add = 0;
int	len, per;

//	save_erase(0);

	dsp_bar(1, -1);
	while(1) {
		len = recv_data(con->sockData, romsc2, 1024);
		if(len <= 0)	break;

		if(add + len <= savesize) {
			if((savetype == 3) && ((add & 0xFFFF) == 0))
				save_format(add);
			per = (int)(((u64)add * 100) / savesize);
			dsp_bar(1, per);
		}
		save_write(add, len);

		add += len;
	}

	dsp_bar(1, 100);
	sendResponseLn(con, "226 Transfer complete.");

	closeDataConnection(con);
	dsp_bar(-1, 0);

	return 1;
}

int ftpCommandSIZE(ftpConnection *con, char* command) 
{
	if(!ftpRestrictedCommand(con, command))
		return 0;

	char* fileName=skipWS(&command[5]);
	trimEndingWS(fileName);

	if(strlen(fileName) <= 0) {
		sendResponseLn(con, "500 'SIZE': command requires a parameter.");
		return 0;
	}

	char filePath[MAX_PATH_LENGTH];
	char file[MAX_PATH_LENGTH];
	char tmp[32];
	int svno = -1;
	int n, j;

	if (strStartsWith(fileName, "/")) {
		strcpy(filePath, fileName);
	} else {
		strcpy(filePath, con->curDir);
		strcat(filePath, fileName);
	}

	for(n = 0; n < filecnt; n++) {
		if(fs[n].type > 0) {
			if(fs[n].type == 2)	svno = n;
			strcpy(file, "/");
			for(j = 0; j < filecnt; j++) {
				if((fs[j].type == 0) && (fs[j].lay < fs[n].lay)) {
					strcat(file, fs[j].filename);
					strcat(file, "/");
				}
			}
			strcat(file, fs[n].filename);
			if(strcmp(file, filePath) == 0)	break;
		}
	}

	if(n >= filecnt) {
		toUpperCase(fileName);
		if((svno != -1) && !endsWith(fileName, "SAV")) {
			sendResponseLn(con, "450 Requested file action not taken.");
			closeDataConnection(con);
			return 0;
		} else	n = svno;
	}

	itoa(tmp, fs[n].filesize);
	sendResponse(con, "213 ");
	sendResponseLn(con, tmp);

	return 1;
}

int ftpCommandMDTM(ftpConnection *con, char* command) 
{
	if(!ftpRestrictedCommand(con, command))
		return 0;

	char* fileName=skipWS(&command[5]);
	trimEndingWS(fileName);

	if(strlen(fileName) <= 0) {
		sendResponseLn(con, "500 'MDTM': command requires a parameter.");
		return 0;
	}

	char filePath[MAX_PATH_LENGTH];
	char file[MAX_PATH_LENGTH];
	char tmp[32];
	int svno = -1;
	int n, j;

	if (strStartsWith(fileName, "/")) {
		strcpy(filePath, fileName);
	} else {
		strcpy(filePath, con->curDir);
		strcat(filePath, fileName);
	}

	for(n = 0; n < filecnt; n++) {
		if(fs[n].type > 0) {
			if(fs[n].type == 2)	svno = n;
			strcpy(file, "/");
			for(j = 0; j < filecnt; j++) {
				if((fs[j].type == 0) && (fs[j].lay < fs[n].lay)) {
					strcat(file, fs[j].filename);
					strcat(file, "/");
				}
			}
			strcat(file, fs[n].filename);
			if(strcmp(file, filePath) == 0)	break;
		}
	}

	if(n >= filecnt) {
		toUpperCase(fileName);
		if((svno != -1) && !endsWith(fileName, "SAV")) {
			sendResponseLn(con, "450 Requested file action not taken.");
			closeDataConnection(con);
			return 0;
		} else	n = svno;
	}

	sprintf(tmp, "%04d%02d%02d%02d%02d%02d", fs[n].year+1900, fs[n].month+1, fs[n].day, fs[n].hh, fs[n].mm, fs[n].ss);
	sendResponse(con, "213 ");
	sendResponseLn(con, tmp);

	return 1;
}


int ftpCommandDELE(ftpConnection *con, char* command) 
{
	if(!ftpRestrictedCommand(con, command))
		return 0;

	char* fileName=skipWS(&command[5]);
	trimEndingWS(fileName);

	if(strlen(fileName) <= 0) {
		sendResponseLn(con, "500 'DELE': command requires a parameter.");
		return 0;
	}


	toUpperCase(fileName);
	if(savetype < 1 || !endsWith(fileName, "SAV")) {
		sendResponseLn(con, "450 Requested file action not taken.");
		closeDataConnection(con);
		return 0;
	}


	save_erase(1);



	sendResponseLn(con, "250 DELE command successful.");

	return 1;
}



int ftpCommandHELP(ftpConnection *con, char* command)
{
	sendResponseLn(con, "214-The following commands are recognized (* =>'s unimplemented).");
	sendResponseLn(con, "214-USER    PASS    ACCT*   CWD     XCWD*   CDUP    XCUP*   SMNT*");
	sendResponseLn(con, "214-QUIT    REIN*   PORT    PASV    TYPE    STRU*   MODE*   RETR");
	sendResponseLn(con, "214-STOR    STOU*   APPE*   ALLO*   REST*   RNFR*   RNTO*   ABOR*");
	sendResponseLn(con, "214-DELE    MDTM    RMD*    XRMD*   MKD*    XMKD*   PWD     XPWD");
	sendResponseLn(con, "214-SIZE    LIST    NLST    SITE    SYST    STAT*   HELP    NOOP");
	sendResponseLn(con, "214 Direct comments to Rudolph.");

	return 0;
}

int ftpCommandSITE(ftpConnection *con, char * command) 
{
	char* param=skipWS(&command[5]);
	trimEndingWS(param);
	toUpperCase(param);
	if(strcmp(param, "HELP")==0) {
		sendResponseLn(con, "214-The following SITE commands are recognized (* =>'s unimplemented).");
		sendResponseLn(con, "214-HELP");
		sendResponseLn(con, "214 Direct comments to Rudolph.");
	} else if(strlen(param)==0) {
		sendResponseLn(con, "500 'SITE' requires argument.");
	} else {
		sendResponse(con, "500 '");
		sendResponse(con, command);
		sendResponseLn(con, "' not understood.");
	}

	return 0;
}

int ftpCommandPORT(ftpConnection *con, char* command) 
{
	int params[6];
	char decimByte[4];
	char* pDecimByte=decimByte;
	char* pParams=skipWS(&command[5]);

print_log(2, pParams);

	int state=0; int err=0; int nbParams=0;
	do {
		if(state==0 && *pParams>='0' && *pParams<='9') {
			state=1;
			pParams--;
		} else if(state==1 && *pParams>='0' && *pParams<='9') {
			if(pDecimByte-decimByte<=2) {
				*(pDecimByte++)=*pParams;
			} else {
				err=1;
			}
		} else if(state==1 && (*pParams==',' || *pParams==0) && nbParams<6) {
			*pDecimByte=0;

			if(strlen(decimByte)==0) {
				err=1;
			} else {
				int param=0;
				char* tmp=decimByte+strlen(decimByte)-1;
				int pow=1;
				while(tmp>=decimByte && err==0) {
					
					if (*tmp>='0' && *tmp<='9') {
						param+= ((*tmp)-48)*pow;
						pow=pow*10;
					} else {
						err=1;
					}

					tmp--;
				}

				if (err==0) {
					params[nbParams++]=param;
					pDecimByte=decimByte;
				}
			}
		} else {
			err=1;
		}

	} while(*(pParams++)!=0 && err==0);

	if(err==0 && state==1 && nbParams==6) {
		con->usePassiveMode=0;

		con->port_addr[0]=(unsigned char) params[0];
		con->port_addr[1]=(unsigned char) params[1];
		con->port_addr[2]=(unsigned char) params[2];
		con->port_addr[3]=(unsigned char) params[3];
		con->port_port=((unsigned char) params[4]<<8) | ((unsigned char) params[5]);
		sendResponseLn(con, "200 PORT command successful.");
	} else {
		con->port_addr[0]=0;
		con->port_addr[1]=0;
		con->port_addr[2]=0;
		con->port_addr[3]=0;
		con->port_port=0;
		sendResponseLn(con, "500 illegal PORT command.");
	}

	return 1;
}

int ftpCommandUSER(ftpConnection *con, char* command) 
{
	if(con->userLoggedIn) {
		sendResponseLn(con, "503 You are already logged in!");
		return 0;
	}

	con->user[0]=0;
	con->pass[0]=0;
	char* pUser=skipWS(&command[5]);
	trimEndingWS(pUser);

	if(strlen(pUser)==0) {
		sendResponseLn(con, "500 'USER': command requires a parameter.");
		return 0;
	}

	strncpy(con->user, pUser, MAX_USER_LENGTH);
	sendResponse(con, "331 Password required for ");
	sendResponse(con, con->user);
	sendResponseLn(con, ".");

	return 1;
}

int ftpCommandPASS(ftpConnection *con, char* command) 
{
	if(con->userLoggedIn) {
		sendResponseLn(con, "503 You are already logged in!");
		return 0;
	}

	if(strlen(con->user)==0) {
		sendResponseLn(con, "503 Login with USER first.");
		return 0;
	}

	con->pass[0] = 0;
	char* pPass=skipWS(&command[5]);
	trimEndingWS(pPass);

	if(strlen(pPass)==0) {
		sendResponseLn(con, "500 'PASS': command requires a parameter.");
		return 0;
	}

	strncpy(con->pass, pPass, MAX_PASS_LENGTH);

	if(strcmp(con->user, ini.user) == 0) {
		if(strcmp(con->user, "anonymous") != 0) {
			if(strcmp(con->pass, ini.pass) != 0) {
				sendResponseLn(con, "530 You're not allowed to log in.");
				con->userLoggedIn = 0;
				con->user[0] = 0;
				con->pass[0] = 0;
				return 0;
			}
		}
	} else {
		sendResponseLn(con, "530 You're not allowed to log in.");
		con->userLoggedIn = 0;
		con->user[0] = 0;
		con->pass[0] = 0;
		return 0;
	}

	sendResponseLn(con, "230 You're logged in.");
	con->userLoggedIn = 1;

	return 1;
}

int ftpCommandTYPE(ftpConnection *con, char* command) 
{
	if(!ftpRestrictedCommand(con, command))
		return 0;

	char* pParam1=skipWS(&command[5]);
	trimEndingWS(pParam1);
	if(strlen(pParam1)==0) {
		sendResponseLn(con, "500 'TYPE': command requires a parameter.");
		return 0;
	}

	if(strlen(pParam1)==1 && (*pParam1=='A' || *pParam1=='E' || *pParam1=='I')) {
		con->transfertType=*pParam1;
		sendResponse(con, "200 Type set to ");
		sendResponse(con, pParam1);
		sendResponseLn(con, ".");
	} else {
		sendResponseLn(con, "500 'TYPE': 2 parameters extended version not understood.");
	}

	return 1;
}

int ftpCommandSYST(ftpConnection *con, char* command) 
{
	if(!ftpRestrictedCommand(con, command))
		return 0;

	sendResponseLn(con, "215 UNIX Type: L8");

	return 1;
}

int ftpCommandPASV(ftpConnection *con, char* command) 
{
	if(!ftpRestrictedCommand(con, command))
		return 0;

	char tmp[32];

	strncpy(tmp, con->serverIp, 31);
	strReplaceChar(tmp, '.', ',');

	sendResponse(con, "227 Entering Passive Mode (");
	sendResponse(con, tmp);
	sendResponse(con, ",");
	itoa(tmp, (pasvPort>>8) & 0xFF);
	sendResponse(con, tmp);
	sendResponse(con, ",");
	itoa(tmp, pasvPort & 0xFF);
	sendResponse(con, tmp);
	sendResponseLn(con, ").");

	openDataConnectionPASV(con);

	return 1;
}

int ftpCommandNOOP(ftpConnection *con, char* command) 
{
	if(!ftpRestrictedCommand(con, command))
		return 0;

	sendResponseLn(con, "200 NOOP command successful.");

	return 1;
}

int ftpCommandQUIT(ftpConnection *con, char* command) 
{
//	closeDataConnection(con);
	sendResponseLn(con, "221 Goodbye.");

	return -1;
}

int ftpCommandABOR(ftpConnection *con, char* command) 
{
	if(!ftpRestrictedCommand(con, command))
		return 0;

	sendResponseLn(con, "200 ABOR command successful.");

	return 1;
}


int ftpRestrictedCommand(ftpConnection *con, char* command)
{
//	if((ftp_config.auth_required) && (!con->userLoggedIn)) {
	if((!con->userLoggedIn)) {
		sendResponseLn(con, "530 Please login with USER and PASS.");
		return 0;
	}

	return 1;
}



int ftpDispatch(ftpConnection *con, char* command) 
{
	char uCommand[MAX_COMMAND_LENGTH+1];
	strncpy(uCommand, command, MAX_COMMAND_LENGTH);
	toUpperCase(uCommand);
//	int renameFrom = 0;

	int ret=0;
	if(strlen(uCommand)>0) {
		if (strcmp(uCommand, "PWD")==0 || strcmp(uCommand, "XPWD")==0) {
			ret=ftpCommandPWD(con, command);
		} else if (strcmp(uCommand, "NLST")==0) {
			ret=ftpCommandNLST(con, command);
		} else if (strcmp(uCommand, "LIST")==0 || strStartsWith(uCommand, "LIST ")) {
			ret=ftpCommandLIST(con, command);
		} else if (strStartsWith(uCommand, "RETR ")) {
			ret=ftpCommandRETR(con, command);
		} else if (strStartsWith(uCommand, "STOR ")) {
			ret=ftpCommandSTOR(con, command);
		} else if (strStartsWith(uCommand, "SIZE ")) {
			ret=ftpCommandSIZE(con, command);
		} else if (strStartsWith(uCommand, "MDTM ")) {
			ret=ftpCommandMDTM(con, command);
		} else if (strStartsWith(uCommand, "ABOR")) {
			ret=ftpCommandABOR(con, command);
		} else if (strStartsWith(uCommand, "DELE ")) {
			ret=ftpCommandDELE(con, command);
//		} else if (strStartsWith(uCommand, "RMD ")) {
//			ret=mftpCommandRMD(con, command);
//		} else if (strStartsWith(uCommand, "MKD ")) {
//			ret=mftpCommandMKD(con, command);
//		} else if (strStartsWith(uCommand, "RNFR ")) {
//			ret=mftpCommandRNFR(con, command);
//			renameFrom = con->renameFrom;
//		} else if (strStartsWith(uCommand, "RNTO ")) {
//			ret=mftpCommandRNTO(con, command);
		} else if (strcmp(uCommand, "CDUP")==0) {
			ret=ftpCommandCWD(con, "CWD ..");
		} else if (strStartsWith(uCommand, "CWD ")) {
			ret=ftpCommandCWD(con, command);
		} else if (strcmp(uCommand, "HELP")==0 || strStartsWith(uCommand, "HELP ")) {
			ret=ftpCommandHELP(con, command);
		} else if (strcmp(uCommand, "SITE")==0 || strStartsWith(uCommand, "SITE ")) {
			ret=ftpCommandSITE(con, command);
		} else if (strStartsWith(uCommand, "PORT ")) {
			ret=ftpCommandPORT(con, command);
		} else if (strStartsWith(uCommand, "USER ")) {
			ret=ftpCommandUSER(con, command);
		} else if (strStartsWith(uCommand, "PASS ")) {
			ret=ftpCommandPASS(con, command);
		} else if (strStartsWith(uCommand, "TYPE ")) {
			ret=ftpCommandTYPE(con, command);
		} else if (strcmp(uCommand, "SYST")==0) {
			ret=ftpCommandSYST(con, command);
		} else if (strcmp(uCommand, "PASV")==0) {
			ret=ftpCommandPASV(con, command);
		} else if (strcmp(uCommand, "NOOP")==0) {
			ret=ftpCommandNOOP(con, command);
		} else if (strcmp(uCommand, "QUIT")==0) {
			ret=ftpCommandQUIT(con, command);
		} else {
			sendResponse(con, "500 ");
			sendResponse(con, command);
			sendResponseLn(con, " not understood.");
		}

//		con->renameFrom = renameFrom;
		if(ret < 0)	return ret;
	}

	return ret;
}
