
#ifdef __cplusplus
extern "C" {
#endif

extern	void print_log(int c, char *msg);

#ifdef __cplusplus
}
#endif

