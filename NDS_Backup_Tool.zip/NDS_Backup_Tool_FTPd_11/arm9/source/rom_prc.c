#include <nds.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "CardRead.h"
#include <nds/card.h>
#include "rom_prc.h"


extern	int	savetype;
extern	u32	savesize;

extern	char	*romhead;
extern	char	*romsc1;
extern	char	*romsc2;

//extern	u32	saveoffs;

extern	void	dsp_bar(int mod, int per);

bool rom_read(u32 add)
{
	if(add & 0x3FF)	return false;

	if(add == 0) {
		memcpy(romsc2, romhead, 512);
		memset(romsc2 + 512, 0x00, 512);
		return true;
	}

	if(add < 0x4000) {
		memset(romsc2, 0x00, 1024);
		return true;
	}

	if(add < 0x8000) {
		memcpy(romsc2, romsc1 + add - 0x4000, 1024);
		return true;
	}


	Read_Data((u8*)romsc2, add);
	Read_Data((u8*)(romsc2 + 512), add + 512);

	return true;
}

/********
u32 HGSS_save()
{
	int i;
	u32 add = 0;

	while(add < 0xFFFFFF) {
		cardReadEeprom(add, (u8*)romsc2, 256, 3); 
		for(i = 1; i < 256; i++) {
			if(romsc2[i - 1] != romsc2[i])
				break;
		}
		if(i < 256)	return(add);

		add += 0x40000;
	}

	return(0);
}
*******/

bool save_read(u32 add)
{
	if(add & 0x3FF)	return false;

	if(add >= savesize) {
		memset(romsc2, 0x00, 1024);
		return true;
	}

	cardReadEeprom(add, (u8*)romsc2, 1024, savetype); 

	return true;
}

bool save_write(u32 add, u32 len)
{
	u32	sz;

	if(savesize <= add)
		return true;

	sz = savesize - add;
	if(sz > len)	sz = len;

	cardWriteEeprom(add, (u8 *)romsc2, sz, savetype);
	return true;
}


bool save_format(u32 add)
{
	cardEepromSectorErase(add);
	return true;
}

bool save_erase(int mod)
{
	u32	add;
	int	per;
	int	len;

	if(mod == 1 && (savetype == 1 || savetype == 2)) {
		dsp_bar(3, -1);
		memset(romsc2, 0xFF, 1024);
		for(add = 0; add < savesize; ) {
			per = (add * 100) / savesize;
			dsp_bar(3, per);
			len = savesize - add;
			if(len > 1024)	len = 1024;
			cardWriteEeprom(add, (u8 *)romsc2, len, savetype);
			add += len;
		}
		dsp_bar(3, 100);
		dsp_bar(-1, 0);
		return true;
	}

	if(savetype != 3)
		return false;


	dsp_bar(3, -1);
	for(add = 0; add < savesize; add += 0x10000) {
		per = (add * 100) / savesize;
		dsp_bar(3, per);
		cardEepromSectorErase(add);
	}
	dsp_bar(3, 100);
	dsp_bar(-1, 0);
	return true;
}

