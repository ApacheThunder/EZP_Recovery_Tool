
struct	ini_file {
//	u8	sv_ip[4];
	u16	port;
//	char	dir[64];
	char	user[32];
	char	pass[32];
	u32	save;
//	u32	trim;
};

extern	struct	ini_file	ini;

struct	FTP_File {
		u8	lay;
		u8	type;		// 0:dir, 1:nds, 2:sav, 3:file
		char	filename[256];
		u32	filesize;
		u8	year;		// - 1970
		u8	month;
		u8	day;
		u8	hh;
		u8	mm;
		u8	ss;
};

extern	struct	FTP_File	fs[];

extern	int	filecnt;

#ifdef __cplusplus
extern "C" {
#endif

extern	void FTPd_ini(void);

extern	void disconnectWifi(void);
extern	bool connectWifi(void);

extern	void setBlocking(int sock);
extern	void setNonBlocking(int sock);

extern	int ftpClientCntl(ftpConnection *con);
extern	int ftpd(void);

#ifdef __cplusplus
}
#endif
