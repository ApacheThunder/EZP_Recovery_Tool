#include <nds.h>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "print_log.h"

#include "tarosa/tarosa_Graphic.h"
#include "tarosa/tarosa_Shinofont.h"
extern uint16* MainScreen;
extern uint16* SubScreen;

#define	YSCROOL	7
static int	ypos = YSCROOL;

extern	char	tbuf[];


void print_log(int c, char *msg) {

	u16	color;

	if(c == 0)	color = RGB15(0, 0, 0);
	if(c == 1)	color = RGB15(0, 0, 31);
	if(c == 2)	color = RGB15(29, 0, 0);

	if(ypos > 14) {
		for( int j=YSCROOL*12+6; j<174; j++ ){
			for( int i=0; i<256; i++ ){
				MainScreen[j*256+i] = MainScreen[(j+12)*256+i];
			}
		}
		for( int j=174; j<186; j++ ){
			for( int i=0; i<256; i++ ){
				Pixel(MainScreen, i, j, RGB15(31, 31, 31));
			}
		}
		ypos--;
	}
	strncpy(tbuf, msg, 41);
	tbuf[41] = 0;
	ShinoPrint(MainScreen, 6, ypos * 12 + 6, (u8*)tbuf, color, RGB15(0, 0, 0), 0);
	ypos++;
}

