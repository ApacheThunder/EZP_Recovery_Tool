
#ifndef maindef_h
#define maindef_h

#define ROMTITLE "NDS Backup Tool FTPd"
#define ROMVERSION "Version 0.10 by Rudolph."
#define ROMDATE ""__DATE__" "__TIME__

#endif

