
#ifdef __cplusplus
extern "C" {
#endif

extern	bool rom_read(u32 add);

extern	u32 HGSS_save(void);

extern	bool save_read(u32 add);
extern	bool save_write(u32 add, u32 len);

extern	bool save_format(u32 add);
extern	bool save_erase(int mod);

#ifdef __cplusplus
}
#endif
