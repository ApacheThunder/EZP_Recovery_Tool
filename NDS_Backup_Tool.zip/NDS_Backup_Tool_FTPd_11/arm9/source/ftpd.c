#include <nds.h>
#include <fat.h>
#include <dswifi9.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "sutils.h"
#include "ftpd_cmd.h"
#include "ftpd.h"

#include "print_log.h"

#include "tarosa/tarosa_Graphic.h"
#include "tarosa/tarosa_Shinofont.h"
extern uint16* MainScreen;
extern uint16* SubScreen;


struct	ini_file	ini;

struct	FTP_File	fs[10];
int	filecnt;

void FTPd_ini()
{
	char	ftpbuf[1024];
	FILE	*ftpini;
	int	len, p, s;
	char	key[20];


	ini.port = 21;
	strcpy(ini.user, "anonymous");
	strcpy(ini.pass, "any@anonymous");
	ini.save = 0;

	ftpini = fopen("/NDS_Backup_Tool_FTPd.ini", "rb");
	if(ftpini == NULL)	return;

	len = fread(ftpbuf, 1, 1024, ftpini);

	p = 0;
	while(p < len) {
		if(ftpbuf[p] == '#' || ftpbuf[p] == '!') {
			while(p < len) {
				if(ftpbuf[p] == 0x0A)
					break;
				p++;
			}
			p++;
		}

		s = 0;
		while(ftpbuf[p] >= 0x20 && ftpbuf[p] < 0x7F) {
			key[s] = ftpbuf[p];
			s++;
			p++;
		}
		key[s] = 0;

		if(strcmp(key, "ServerPort") == 0) {
			ini.port = 0;
			while(p < len) {
				if(ftpbuf[p] >= 0x30 && ftpbuf[p] <= 0x39)
					break;
				p++;
			}
			while(p < len) {
				if(ftpbuf[p] < 0x30 || ftpbuf[p] > 0x39)
					break;
				ini.port = ini.port * 10 + ftpbuf[p] - 0x30;
				p++;
			}
		}

		if(strcmp(key, "FTPUser") == 0) {
			s = 0;
			while(p < len) {
				if(ftpbuf[p] == 0x20 || ftpbuf[p] == '\t')
					p++;
				else	break;
			}
			while(p < len) {
				if(ftpbuf[p] <= 0x20 || ftpbuf[p] >= 0x7F)
					break;
				if(s < 31)
					ini.user[s] = ftpbuf[p];
				s++;
				p++;
			}
			ini.user[s] = 0;
		}
		if(strcmp(key, "FTPPassword") == 0) {
			s = 0;
			while(p < len) {
				if(ftpbuf[p] == 0x20 || ftpbuf[p] == '\t')
					p++;
				else	break;
			}
			while(p < len) {
				if(ftpbuf[p] <= 0x20 || ftpbuf[p] >= 0x7F)
					break;
				if(s < 31)
					ini.pass[s] = ftpbuf[p];
				s++;
				p++;
			}
			ini.pass[s] = 0;
		}
		if(strcmp(key, "SaveFile") == 0) {
			ini.save = 0;
			while(p < len) {
				if(ftpbuf[p] >= 0x30 && ftpbuf[p] <= 0x39)
					break;
				p++;
			}
			while(p < len) {
				if(ftpbuf[p] < 0x30 || ftpbuf[p] > 0x39)
					break;
				ini.save = ini.save * 10 + ftpbuf[p] - 0x30;
				p++;
			}
		}

		while(p < len) {
			p++;
			if(ftpbuf[p - 1] == 0x0A)
				break;
		}
	}

	fclose(ftpini);

}


static bool wifiConnected = false;

void disconnectWifi()
{
	if(!wifiConnected)
		return;

	wifiConnected = false;

	Wifi_DisconnectAP();
	Wifi_DisableWifi();
}

bool connectWifi()
{
	if(wifiConnected)
		return true;

	return Wifi_InitDefault(WFC_CONNECT);
}

void setBlocking(int sock)
{
	int i = 0;

	ioctl(sock, FIONBIO, &i);	 // set blocking
}

void setNonBlocking(int sock)
{
	int i = 1;

	ioctl(sock, FIONBIO, &i);	 // set non-blocking
}


extern	int inp_cmd(void);
extern	void dsp_cmd(int);
extern	void dsp_connect(char *ip);

int ftpClientCntl(ftpConnection *con)
{
//char aa[10];

	con->sockData = 0;
	con->sockPASV = 0;

	memset(con->sockCommandBuffer, 0, 1024);
	memset(con->sockDataBuffer, 0, 1024);
	con->lay = 0;		// root dir
	strcpy(con->curDir, "/");
//	strcpy(con->root,"/");
	memset(con->user, 0, MAX_USER_LENGTH);
	memset(con->pass, 0, MAX_PASS_LENGTH);
//	strcpy(con->renameFromFileName,"");
//	con->renameFrom = 0;
	con->usePassiveMode = 0;
	con->userLoggedIn = 0;
	con->port_port = 0;
	con->port_addr[0] = 0;
	con->port_addr[1] = 0;
	con->port_addr[2] = 0;
	con->port_addr[3] = 0;
	con->transfertType = 'A';

	setNonBlocking(con->sockCommand);


	ftpServerHello(con);

	char readBuffer[1024];
	char lineBuffer[1024];
	int lineLen=0;
	int errLoop=0;
	int	ret = 0;

	while(errLoop >= 0) {

		dsp_cmd(0);
		ret = inp_cmd();
		if(ret != 0)	break;

		int nb = recv(con->sockCommand, (u8*)readBuffer, 1024, 0);
		if(nb < 0) {
			errLoop++;
			if(errLoop > 100000000)
				errLoop = -1;
			continue;
		}
		errLoop = 0;

	  	int i = 0; 
	  	while(i < nb) {
	  		if(readBuffer[i] != '\r') {
//if(readBuffer[i] >= 0x7F) {
//sprintf(aa, "%02X", readBuffer[i]);
//print_log(1, aa);
//} else
				lineBuffer[lineLen++] = readBuffer[i];
				if(readBuffer[i]=='\n' || lineLen==1024) {
  					lineBuffer[--lineLen] = 0;
  					char* command=skipWS(lineBuffer);
  					trimEndingWS(command);

//          snprintf(messBuffer, 64, "> %s from %s", command, con->clientIp);
//          mftpAddNewStatusMessage(messBuffer);


					dsp_cmd(1);
					print_log(0, command);

					lineLen = 0;
					if((errLoop = ftpDispatch(con, command)) < 0)
						break;		// QUIT
				}
			}
			i++;
		}
	}

//	sendResponseLn(con, "221 Goodbye.");
	print_log(1, "logout");

	return ret;
}



int ftpd()
{
	int rc;
	fd_set mask;
	struct timeval tv;

	vu32	vi;
	u32 err;
	int	ret;

	int sockListen;
	int sockClient;

	struct sockaddr_in addrListen;
	struct sockaddr_in addrAccept;
	int cbAddrAccept;
	struct in_addr ip;


	sockListen = socket(AF_INET, SOCK_STREAM, 0);
	if(sockListen & 0x80000000)	return -1;

	addrListen.sin_family = AF_INET;
	addrListen.sin_port = htons(21);
	addrListen.sin_addr.s_addr = 0;

	err = bind(sockListen, (struct sockaddr *)&addrListen, sizeof(addrListen));
	if(!err) {
//		setNonBlocking(sockListen);
		err = listen(sockListen, 1);
	}
	if(err) {
		closesocket(sockListen);
		return -1;
	}

	while (1) {
		cbAddrAccept = sizeof(addrAccept);

		while(1) {
			dsp_connect(NULL);

			FD_ZERO(&mask);
			FD_SET(sockListen, &mask);
			tv.tv_sec = 0;
			tv.tv_usec = 250*1000;
			rc = select((int)sockListen+1, &mask, NULL, NULL, &tv);
			if(rc != 0) break;

			dsp_cmd(0);
			ret = inp_cmd();
			if(ret != 0)	break;
		}
		if(ret != 0)	break;


		sockClient = accept(sockListen, (struct sockaddr *)&addrAccept, &cbAddrAccept);
		if(sockClient & 0x80000000) {
//print_log(2, "ACCEPT ERROR");
			break;
		}

		ftpConnection* con=(ftpConnection*)malloc(sizeof(ftpConnection));

		ip.s_addr = Wifi_GetIP();
		strcpy(con->serverIp, inet_ntoa(ip));

		strcpy(con->clientIp, inet_ntoa(addrAccept.sin_addr));
		dsp_connect(con->clientIp);

		con->sockCommand = sockClient;

		ret = ftpClientCntl(con);

		shutdown(sockClient, 0);
		for(vi = 0; vi < 50; vi++)	// 1000ms
			swiWaitForVBlank();
		closesocket(sockClient);
		free(con);
		print_log(2, "quit");
		if(ret != 0)	break;
	}

	dsp_connect(NULL);
	closesocket(sockListen);

	return(ret);
}

