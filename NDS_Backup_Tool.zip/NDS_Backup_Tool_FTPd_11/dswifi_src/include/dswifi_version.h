#ifndef _dswifi_version_h_
#define _dswifi_version_h_

#define DSWIFI_MAJOR    0
#define DSWIFI_MINOR    3
#define DSWIFI_REVISION 10

#define DSWIFI_VERSION "0.3.10"

#endif // _dswifi_version_h_
