#include <nds.h>
#include <stdlib.h>
#include <string.h>

#include "LibCardDump.h"

#define cWAIT_1ms 16755

static bool	cardopen = false;
static char	*key2tbl;
static char	*key1tbl;
static char	*romhead = NULL;
static char	*romsc1 = NULL;

static u32	kkkkk;
static u32	llll;
static u32	iiijjj;
static u32	mmmnnn;
static u32	EncSeed;

static u32	chip_id;
static u32	Gamecode;
static u32	cr2_normal;
static u32	cr2_key1;


extern	void	port_setcmd(u32* normal, u32* key1, u8* header);
extern	int	key1_cmd(u32 cmd1, u32 cmd2, u32 id, u8* tbl);
extern	void	enc_key2(u32 mmmnnn, u8 key2);
extern	void	encryObj(u32 Gamecode, u8* sc1, u8* tbl);


static void Read_Init()
{
	llll = 0xE71F;
	iiijjj = 1;
	mmmnnn = 2;
	kkkkk = 3;

	CARD_CR2 = 0x00;
	CARD_CR1H = 0x00;
	swiDelay(10 * cWAIT_1ms);
	CARD_CR1H = 0xC0;
	CARD_CR2 = 0x20008000;
}


static int Read_dummy()
{
	int	s;
	vu32	data;

	while(CARD_CR2 & CARD_BUSY);

	CARD_CR1H = 0xC0;
	CARD_COMMAND[0] = 0x9F;
	CARD_COMMAND[1] = 0x00;
	CARD_COMMAND[2] = 0x00;
	CARD_COMMAND[3] = 0x00;
	CARD_COMMAND[4] = 0x00;
	CARD_COMMAND[5] = 0x00;
	CARD_COMMAND[6] = 0x00;
	CARD_COMMAND[7] = 0x00;

	CARD_CR2 = 0xAD180000;

	s = 0;
	do {
		if((CARD_CR2 & CARD_DATA_READY)) {
			if(s < 0x2000) {
				data = CARD_DATA_RD;
				s += 4;
			}
		}
	} while(CARD_CR2 & CARD_BUSY);

	return(s);

}


static int Read_Header(u8* header)
{
	int	s;
	u32	data;
	u32	*buf;

	while(CARD_CR2 & CARD_BUSY);

	CARD_CR1H = 0xC0;
	CARD_COMMAND[0] = 0x00;
	CARD_COMMAND[1] = 0x00;
	CARD_COMMAND[2] = 0x00;
	CARD_COMMAND[3] = 0x00;
	CARD_COMMAND[4] = 0x00;
	CARD_COMMAND[5] = 0x00;
	CARD_COMMAND[6] = 0x00;
	CARD_COMMAND[7] = 0x00;

//	CARD_CR2 = 0xAC3F1FFF;
	CARD_CR2 = 0xA93F1FFF;
	s = 0;
	buf = (u32*)header;
	do {
		if((CARD_CR2 & CARD_DATA_READY)) {
			if(s < 0x200) {
				data = CARD_DATA_RD;
				*buf = data;
				buf++;
				s += 4;
			}
		}
	} while(CARD_CR2 & CARD_BUSY);


	Gamecode = *((u32*)(header + 0x0C));
	EncSeed = (u32)(header[0x13] & 0x07);
//	cr2_normal = *((u32*)(header + 0x60));
//	cr2_key1 = *((u32*)(header + 0x64));
	port_setcmd(&cr2_normal, &cr2_key1, header);

	if((header[0x63] & 0x08) == 0x08) {
		cr2_normal |= 0x08000000;
		cr2_key1 |= 0x08000000;
	}

	return(s);
}

static u32 Read_CardID_1()
{
	while(CARD_CR2 & CARD_BUSY);

	CARD_CR1H = 0xC0;
	CARD_COMMAND[0] = 0x90;
	CARD_COMMAND[1] = 0x00;
	CARD_COMMAND[2] = 0x00;
	CARD_COMMAND[3] = 0x00;
	CARD_COMMAND[4] = 0x00;
	CARD_COMMAND[5] = 0x00;
	CARD_COMMAND[6] = 0x00;
	CARD_COMMAND[7] = 0x00;

//	CARD_CR2 = cr2_normal | 0xA7000000;
	CARD_CR2 = 0xA7000000;

	while(!(CARD_CR2 & CARD_DATA_READY));

	chip_id = CARD_DATA_RD;
	return(chip_id);
}


static bool Act_Key1()
{

	while(CARD_CR2 & CARD_BUSY);

	CARD_CR1H = 0xC0;
	CARD_COMMAND[0] = 0x3C;
	CARD_COMMAND[1] = (iiijjj >> 16) & 0xFF;
	CARD_COMMAND[2] = (iiijjj >> 8) & 0xFF;
	CARD_COMMAND[3] = iiijjj & 0xFF;

	CARD_COMMAND[4] = (kkkkk >> 16) & 0x0F;
	CARD_COMMAND[5] = (kkkkk >> 8) & 0xFF;
	CARD_COMMAND[6] = kkkkk & 0xFF;

	CARD_COMMAND[7] = 0x00;

	CARD_CR2 = 0xA0010017;

	return true;
}



//====================================================


static void Act_Key2()
{
	u32	cmd1, cmd2;


	cmd1 = (mmmnnn << 20) | kkkkk;
	cmd2 = 0x40000000 | (llll << 12) | (mmmnnn >> 12);
	key1_cmd(cmd1, cmd2, Gamecode, (u8*)key1tbl);
	swiDelay(5 * cWAIT_1ms);
	enc_key2(mmmnnn, key2tbl[EncSeed]);

	if(chip_id < 0x80000000) {
		CARD_CR2 = cr2_key1 | 0xB0008000;
	} else {
		CARD_CR2 = 0xA0000000;
		swiDelay(30 * cWAIT_1ms);
		CARD_CR2 = 0xA0008000;
	}

	kkkkk++;
	kkkkk &= 0xFFFFF;
}

static u32 Read_CardID_2()
{
	u32	cmd1, cmd2;
	u32	data;

	cmd1 = (iiijjj << 20) | kkkkk;
	cmd2 = 0x10000000 | (llll << 12) | (iiijjj >> 12);
	key1_cmd(cmd1, cmd2, Gamecode, (u8*)key1tbl);
	swiDelay(10 * cWAIT_1ms);
	if(chip_id < 0x80000000) {
		CARD_CR2 = cr2_key1 | 0xB7006000;
	} else {
		CARD_CR2 = 0xA0006000;
		swiDelay(30 * cWAIT_1ms);
		CARD_CR2 = 0xA7006000;
	}

	while(!(CARD_CR2 & CARD_DATA_READY));
	data = CARD_DATA_RD;

	kkkkk++;
	kkkkk &= 0xFFFFF;

	return(data);
}



static int Read_SData(u8* dbuf, u32 addr)
{
	u32	cmd1, cmd2;
	int	s;
	u32	data;
	u32	*buf;
	int	n;

	cmd1 = (iiijjj << 20) | kkkkk;
	cmd2 = 0x20000000 | addr | (iiijjj >> 12);
	key1_cmd(cmd1, cmd2, Gamecode, (u8*)key1tbl);
	swiDelay(5 * cWAIT_1ms);

	s = 0;
	buf = (u32*)dbuf;

	if(chip_id < 0x80000000) {
		CARD_CR2 = cr2_normal | 0xB4006000;
		do {
			if((CARD_CR2 & CARD_DATA_READY)) {
				if(s < 0x1000) {
					data = CARD_DATA_RD;
					*buf = data;
					buf++;
					s += 4;
				}
			}
		} while(CARD_CR2 & CARD_BUSY);
	} else {
		CARD_CR2 = cr2_normal | 0xA0006000;
		swiDelay(30 * cWAIT_1ms);
		for(n = 0; n < 8; n++) {
			CARD_CR2 = cr2_normal | 0xA1006000;
			do {
				if((CARD_CR2 & CARD_DATA_READY)) {
					if(s < 0x1000) {
						data = CARD_DATA_RD;
						*buf = data;
						buf++;
						s += 4;
					}
				}
			} while(CARD_CR2 & CARD_BUSY);
		}
	}

	kkkkk++;
	kkkkk &= 0xFFFFF;

	return(s);

}


static void Data_Mode()
{
	u32	cmd1, cmd2;


	cmd1 = (iiijjj << 20) | kkkkk;
	cmd2 = 0xA0000000 | (llll << 12) | (iiijjj >> 12);
	key1_cmd(cmd1, cmd2, Gamecode, (u8*)key1tbl);
	swiDelay(5 * cWAIT_1ms);

	enc_key2(mmmnnn, key2tbl[EncSeed]);


	if(chip_id < 0x80000000) {
		CARD_CR2 = cr2_key1 | 0xB0006000;
	} else {
		CARD_CR2 = cr2_key1 | 0xA0006000;
		swiDelay(30 * cWAIT_1ms);
		CARD_CR2 = cr2_key1 | 0xA0006000;
	}

	kkkkk++;
	kkkkk &= 0xFFFFF;

}



static int Read_Data(u8* dbuf, u32 addr)
{
	int	s;
	u32	data;
	u32	*buf;

	while(CARD_CR2 & CARD_BUSY);

	CARD_CR1H = 0xC0;
	CARD_COMMAND[0] = 0xB7;
	CARD_COMMAND[1] = (addr >> 24) & 0xFF;
	CARD_COMMAND[2] = (addr >> 16) & 0xFF;
	CARD_COMMAND[3] = (addr >> 8) & 0xFF;
	CARD_COMMAND[4] = addr & 0xFF;

	CARD_COMMAND[5] = 0x00;
	CARD_COMMAND[6] = 0x00;
	CARD_COMMAND[7] = 0x00;

	CARD_CR2 = (cr2_normal & 0xF8FFFFFF) | 0xA1406000;
//	CARD_CR2 = 0xA9407000;
//	CARD_CR2 = 0xA1586000;

	s = 0;
	buf = (u32*)dbuf;
	do {
		if((CARD_CR2 & CARD_DATA_READY)) {
			if(s < 0x200) {
				data = CARD_DATA_RD;
				*buf = data;
				buf++;
				s += 4;
			}
		}
	} while(CARD_CR2 & CARD_BUSY);

	return(s);
}

static u32 Read_CardID_3()
{
	while(CARD_CR2 & CARD_BUSY);

	CARD_CR1H = 0xC0;
	CARD_COMMAND[0] = 0xB8;
	CARD_COMMAND[1] = 0x00;
	CARD_COMMAND[2] = 0x00;
	CARD_COMMAND[3] = 0x00;
	CARD_COMMAND[4] = 0x00;
	CARD_COMMAND[5] = 0x00;
	CARD_COMMAND[6] = 0x00;
	CARD_COMMAND[7] = 0x00;

//	CARD_CR2 = cr2_normal | 0xA7000000;
	CARD_CR2 = 0xA7416017;

	while(!(CARD_CR2 & CARD_DATA_READY));

	return(CARD_DATA_RD);
}


static u32 Rom_Read(int type, u8* header, u8* sc1)
{
	u32	id, id2, id3;
	u32	i;
	u8	*ptr;

	if(type == 0) {
		Read_Init();
	}

	Read_dummy();

	id = Read_CardID_1();

	if(type == 0) {
		Read_dummy();
	}

	swiDelay(10 * cWAIT_1ms);

	Read_Header(header);
	swiDelay(500 * cWAIT_1ms);

	Act_Key1();

	if(id == 0 || id == 0xFFFFFFFF)
		return(0xFFFFFFFF);

	Act_Key2();
	id2 = Read_CardID_2();
	if(id != id2)	return(0xFFFFFFFF);

	ptr = sc1;
	for(i = 0x4000; i < 0x8000; i += 0x1000) {
		Read_SData(ptr, i);
		ptr += 0x1000;
	}

	id2 = Read_CardID_2();
	if(id != id2)	return(0xFFFFFFFF);

	Data_Mode();

	id3 = Read_CardID_3();
	if(id != id3)	return(0xFFFFFFFF);

	encryObj(Gamecode, sc1, (u8*)key1tbl);

	return(id);
}




// Card recognition and initialization of card dump.
u32 Card_Open(char *key_tbl)
{
	if(cardopen == 0) {
		key2tbl = key_tbl + 0x2A;
		key1tbl = key_tbl + 0x30;
		romhead = (char *)malloc(0x200);
		romsc1 = (char *)malloc(0x4000);
		cardopen = true;
	}

	return(Rom_Read(0, (u8*)romhead, (u8*)romsc1));
}


// Recognizing of card retry.
u32 Card_Retry(void)
{
	return(Rom_Read(1, (u8*)romhead, (u8*)romsc1));
}


// Card dump of specified address(512*n)
bool Card_Read(u32 addr, char *data)
{
	if(addr & 0x1FF)	return false;

	if(addr == 0) {
		memcpy(data, romhead, 512);
		return true;
	}

	if(addr < 0x4000) {
		memset(data, 0x00, 512);
		return true;
	}

	if(addr < 0x8000) {
		memcpy(data, romsc1 + addr - 0x4000, 512);
		return true;
	}

	Read_Data((u8*)data, addr);
	return true;
}

// End of card dump
bool Card_Close(void)
{
	if(cardopen) {
		free(romhead);
		free(romsc1);
		cardopen = false;
		return true;
	}

	return false;
}
