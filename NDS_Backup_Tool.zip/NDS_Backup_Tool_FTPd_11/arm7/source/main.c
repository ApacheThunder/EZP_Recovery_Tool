/*---------------------------------------------------------------------------------

default ARM7 core

Copyright (C) 2005
Michael Noland (joat)
Jason Rogers (dovoto)
Dave Murphy (WinterMute)

This software is provided 'as-is', without any express or implied
warranty.  In no event will the authors be held liable for any
damages arising from the use of this software.

Permission is granted to anyone to use this software for any
purpose, including commercial applications, and to alter it and
redistribute it freely, subject to the following restrictions:

1.	The origin of this software must not be misrepresented; you
must not claim that you wrote the original software. If you use
this software in a product, an acknowledgment in the product
documentation would be appreciated but is not required.
2.	Altered source versions must be plainly marked as such, and
must not be misrepresented as being the original software.
3.	This notice may not be removed or altered from any source
distribution.

---------------------------------------------------------------------------------*/
#include <nds.h>
#include <dswifi7.h>
//#include <maxmod7.h>

#define NDS_TYPE	 (*(vu8*)0x027FFDF0)
#define KEY_TBL_ADR	(*(vu32*)0x027FFDF4)

//---------------------------------------------------------------------------------
void VcountHandler() {
//---------------------------------------------------------------------------------
	inputGetAndSend();
}

//---------------------------------------------------------------------------------
void VblankHandler(void) {
//---------------------------------------------------------------------------------
	Wifi_Update();
}


u8 PM_GetRegister(int reg)
{
	SerialWaitBusy();
 
	REG_SPICNT = SPI_ENABLE | SPI_DEVICE_POWER | SPI_BAUD_1MHz | SPI_CONTINUOUS;
	REG_SPIDATA = reg | 0x80;
 
	SerialWaitBusy();
 
	REG_SPICNT = SPI_ENABLE | SPI_DEVICE_POWER | SPI_BAUD_1MHz ;
	REG_SPIDATA = 0;
 
	SerialWaitBusy();

	return REG_SPIDATA & 0xff;
}

//---------------------------------------------------------------------------------
static uint16 main_InitNDSL_touchRead(uint32 command) {
//---------------------------------------------------------------------------------
	uint16 result;
	SerialWaitBusy();

	// Write the command and wait for it to complete
	REG_SPICNT = SPI_ENABLE | SPI_BAUD_2MHz | SPI_DEVICE_TOUCH | SPI_CONTINUOUS; //0x0A01;
	REG_SPIDATA = command;
	SerialWaitBusy();

	// Write the second command and clock in part of the data
	REG_SPIDATA = 0;
	SerialWaitBusy();
	result = REG_SPIDATA;

	// Clock in the rest of the data (last transfer)
	REG_SPICNT = SPI_ENABLE | 0x201;
	REG_SPIDATA = 0;
	SerialWaitBusy();

	// Return the result
	return ((result & 0x7F) << 5) | (REG_SPIDATA >> 3);
}


#define PM_NDSLITE_ADR (4)
#define PM_NDSLITE_ISLITE BIT(6)
#define PM_NDSLITE_ExternalPowerPresent BIT(3)

static inline void NDS_typechk(void)
{
//	NDS_TYPE = 0x00;

	u32 td1=main_InitNDSL_touchRead(TSC_MEASURE_TEMP1);
	u32 td2=main_InitNDSL_touchRead(TSC_MEASURE_TEMP2);
	if((td1==0x0fff)&&(td2==0x0fff)){
		NDS_TYPE = 0x83;	// AC:DSi�͒��ׂĂ��Ȃ��̂ŏ�ɐڑ�����Ă��邱�Ƃɂ���B
		return;
	}

	if((PM_GetRegister(PM_NDSLITE_ADR) & PM_NDSLITE_ISLITE) == 0) {
		NDS_TYPE = 0x81;	// AC:��DS�͕s���Ȓl��Ԃ��̂ŏ�ɐڑ�����Ă��邱�Ƃɂ���B
		return;
	}

	NDS_TYPE = 0x02;
	if(PM_GetRegister(PM_NDSLITE_ADR) & PM_NDSLITE_ExternalPowerPresent)
		NDS_TYPE |= 0x80;

}




extern	void	ARM7_Bios(u8* ptr);
//---------------------------------------------------------------------------------
int main() {
//---------------------------------------------------------------------------------

////////////////////
	u8	*tbl;
	KEY_TBL_ADR = 0;
////////////////////


	// read User Settings from firmware
	readUserSettings();

	powerOn(POWER_SOUND);

	irqInit();
	fifoInit();


	SetYtrigger(80);

	installWifiFIFO();
//	installSoundFIFO();
//	mmInstall(FIFO_MAXMOD);

	installSystemFIFO();

	irqSet(IRQ_VCOUNT, VcountHandler);
	irqSet(IRQ_VBLANK, VblankHandler);

	// Start the RTC tracking IRQ
	initClockIRQ();

	irqEnable( IRQ_VBLANK | IRQ_VCOUNT | IRQ_NETWORK);

/////////////////
	while(KEY_TBL_ADR == 0)
		swiWaitForVBlank();

	tbl = (u8*)KEY_TBL_ADR;
	ARM7_Bios(tbl);

	NDS_typechk();
/////////////////

	// Keep the ARM7 mostly idle
	while (1) swiWaitForVBlank();
}
